// ========================================
// ELEKTRİK LAB - SCRIPT.JS | SÜRÜM 3.0
// ========================================

function getElement(id) {
  return document.getElementById(id);
}



function getNumber(id) {
  const el = getElement(id);
  if (!el) return null;

  const raw = el.value.trim().replace(',', '.');

  if (raw === '') {
    delete el.dataset.invalidNumber;
    return null;
  }

  const n = Number(raw);

  if (!Number.isFinite(n)) {
    el.dataset.invalidNumber = 'true';
    return null;
  }

  delete el.dataset.invalidNumber;
  return n;
}



function formatNumber(value, digits = 6) {
  if (!Number.isFinite(value)) return 'Hesaplanamadı';
  return value.toLocaleString('tr-TR', {
    maximumFractionDigits: digits
  });
}


function showResult(id, message, isError = false) {
    const el = getElement(id);
    if (!el) return;

    if (isError) {
        el.textContent = message;
    } else {
        el.innerHTML = message;
    }

    el.classList.add('show');
    el.classList.toggle('error', isError);

    if (!isError && typeof saveCalculationHistory === 'function') {
        saveCalculationHistory(id, el.innerText);
    }
}


function clearResult(id) {
  const el = getElement(id);
  if (el) {
    el.textContent = '';
    el.classList.remove('show', 'error');
  }
}

function positiveValues(values) {
  return values.every(v => v !== null && v > 0);
}

function showPage(pageId) {
  document.querySelectorAll('.page').forEach(page => {
    page.classList.toggle('active', page.id === pageId);
  });

  document.querySelectorAll('.nav-btn').forEach(button => {
    button.classList.toggle('active', button.dataset.page === pageId);
  });

  window.scrollTo({ top: 0, behavior: 'smooth' });
}

// ========================================
// 1 - OHM KANUNU
// ========================================

function calculateOhm() {
  const V = getNumber('voltage');
  const I = getNumber('current');
  const R = getNumber('resistanceOhm');

  const count = [V, I, R].filter(v => v !== null).length;

  if (count !== 2) {
    return showResult(
      'ohmResult',
      'Üç değerden yalnızca ikisini gir. Üçüncü değer hesaplanacaktır.',
      true
    );
  }

  if ([V, I, R].some(v => v !== null && v < 0)) {
    return showResult('ohmResult', 'Değerler negatif olamaz.', true);
  }

  if (V === null) {
    return showResult(
      'ohmResult',
      `Hesaplanan Gerilim: ${formatNumber(I * R)} V`
    );
  }

  if (I === null) {
    if (R === 0) {
      return showResult(
        'ohmResult',
        'Direnç sıfır olduğundan akım hesabı yapılamaz.',
        true
      );
    }

    return showResult(
      'ohmResult',
      `Hesaplanan Akım: ${formatNumber(V / R)} A`
    );
  }

  if (I === 0) {
    return showResult(
      'ohmResult',
      'Akım sıfır olduğundan V/I ile direnç hesaplanamaz.',
      true
    );
  }

  showResult(
    'ohmResult',
    `Hesaplanan Direnç: ${formatNumber(V / I)} Ω`
  );
}

// ========================================
// 2 - DC GÜÇ
// ========================================

function calculateDCPower() {
  const V = getNumber('powerVoltage');
  const I = getNumber('powerCurrent');

  if (V === null || I === null) {
    return showResult(
      'powerResult',
      'Gerilim ve akım değerlerini gir.',
      true
    );
  }

  if (V < 0 || I < 0) {
    return showResult(
      'powerResult',
      'Gerilim ve akım negatif olamaz.',
      true
    );
  }

  const P = V * I;

  if (!Number.isFinite(P)) {
    return showResult(
      'powerResult',
      'Girilen değerler hesaplama sınırını aşıyor.',
      true
    );
  }

  showResult(
    'powerResult',
    `Gerilim: ${formatNumber(V)} V
Akım: ${formatNumber(I)} A
Güç: ${formatNumber(P)} W
Güç: ${formatNumber(P / 1000)} kW`
  );
}

// ========================================
// 3 - SERİ / PARALEL DİRENÇ
// ========================================

function calculateResistance() {
  const type = getElement('resistorType').value;
  const raw = getElement('resistorValues').value.trim();

  if (!raw) {
    return showResult(
      'resistanceResult',
      'Direnç değerlerini gir.',
      true
    );
  }

  const values = raw
    .split(/[;,\s]+/)
    .filter(Boolean)
    .map(Number);

  if (
    !values.length ||
    values.some(v => !Number.isFinite(v) || v <= 0)
  ) {
    return showResult(
      'resistanceResult',
      'Sıfırdan büyük ve geçerli direnç değerleri gir. Ondalık ayırıcı olarak nokta kullan.',
      true
    );
  }

  const req = type === 'series'
    ? values.reduce((a, b) => a + b, 0)
    : 1 / values.reduce((a, b) => a + 1 / b, 0);

  if (!Number.isFinite(req)) {
    return showResult(
      'resistanceResult',
      'Sonuç hesaplanamadı; değerleri kontrol et.',
      true
    );
  }

  showResult(
    'resistanceResult',
    `Bağlantı Türü: ${type === 'series' ? 'Seri' : 'Paralel'}
Direnç Sayısı: ${values.length}
Eşdeğer Direnç: ${formatNumber(req)} Ω`
  );
}

// ========================================
// 4 - BİRİM DÖNÜŞTÜRME
// ========================================

const unitDefinitions = {
  voltage: {
    name: 'Gerilim',
    units: [
      ['µV', 1e-6],
      ['mV', 1e-3],
      ['V', 1],
      ['kV', 1e3],
      ['MV', 1e6],
      ['GV', 1e9]
    ]
  },

  current: {
    name: 'Akım',
    units: [
      ['µA', 1e-6],
      ['mA', 1e-3],
      ['A', 1],
      ['kA', 1e3],
      ['MA', 1e6]
    ]
  },

  power: {
    name: 'Güç',
    units: [
      ['µW', 1e-6],
      ['mW', 1e-3],
      ['W', 1],
      ['kW', 1e3],
      ['MW', 1e6],
      ['GW', 1e9]
    ]
  },

  resistance: {
    name: 'Direnç',
    units: [
      ['mΩ', 1e-3],
      ['Ω', 1],
      ['kΩ', 1e3],
      ['MΩ', 1e6],
      ['GΩ', 1e9]
    ]
  },

  energy: {
    name: 'Enerji',
    units: [
      ['mWh', 1e-3],
      ['Wh', 1],
      ['kWh', 1e3],
      ['MWh', 1e6],
      ['GWh', 1e9]
    ]
  },

  capacitance: {
    name: 'Kapasitans',
    units: [
      ['pF', 1e-12],
      ['nF', 1e-9],
      ['µF', 1e-6],
      ['mF', 1e-3],
      ['F', 1]
    ]
  },

  inductance: {
    name: 'Endüktans',
    units: [
      ['µH', 1e-6],
      ['mH', 1e-3],
      ['H', 1]
    ]
  },

  frequency: {
    name: 'Frekans',
    units: [
      ['mHz', 1e-3],
      ['Hz', 1],
      ['kHz', 1e3],
      ['MHz', 1e6],
      ['GHz', 1e9]
    ]
  }
};

function populateUnitOptions() {
  const category = unitDefinitions[getElement('convertCategory').value];
  const from = getElement('convertFrom');
  const to = getElement('convertTo');

  if (!category || !from || !to) return;

  from.innerHTML = '';
  to.innerHTML = '';

  category.units.forEach((unit, index) => {
    for (const element of [from, to]) {
      const option = document.createElement('option');
      option.value = String(index);
      option.textContent = unit[0];
      element.appendChild(option);
    }
  });

  from.value = String(Math.min(1, category.units.length - 1));
  to.value = String(Math.min(2, category.units.length - 1));

  clearResult('convertResult');
}

function convertUnit() {
  const value = getNumber('convertValue');
  const category = unitDefinitions[getElement('convertCategory').value];
  const fromIndex = Number(getElement('convertFrom').value);
  const toIndex = Number(getElement('convertTo').value);

  if (value === null) {
    return showResult(
      'convertResult',
      'Dönüştürülecek geçerli bir değer gir.',
      true
    );
  }

  const fromUnit = category?.units[fromIndex];
  const toUnit = category?.units[toIndex];

  if (!fromUnit || !toUnit) {
    return showResult(
      'convertResult',
      'Geçerli birim seçimi yap.',
      true
    );
  }

  const result = value * fromUnit[1] / toUnit[1];

  if (!Number.isFinite(result)) {
    return showResult(
      'convertResult',
      'Bu değer için sonuç hesaplanamadı.',
      true
    );
  }

  showResult(
    'convertResult',
    `Büyüklük: ${category.name}
Başlangıç: ${formatNumber(value, 10)} ${fromUnit[0]}
Sonuç: ${formatNumber(result, 10)} ${toUnit[0]}`
  );
}

function swapUnits() {
  const from = getElement('convertFrom');
  const to = getElement('convertTo');

  const oldValue = from.value;
  from.value = to.value;
  to.value = oldValue;

  if (getNumber('convertValue') !== null) {
    convertUnit();
  }
}// ========================================
// 5 - AC GÜÇ
// ========================================

function calculateACPower() {
  const phase = getElement('acPhase').value;
  const V = getNumber('acVoltage');
  const I = getNumber('acCurrent');
  const pf = getNumber('powerFactor');
  const loadType = getElement('acLoadType')?.value || 'lagging';

  if ([V, I, pf].some(v => v === null)) {
    return showResult('acPowerResult', 'Gerilim, akım ve güç faktörünü gir.', true);
  }

  if (V <= 0 || I < 0 || pf < 0 || pf > 1) {
    return showResult('acPowerResult', 'Gerilim pozitif, akım negatif olmayan ve güç faktörü 0-1 arasında olmalıdır.', true);
  }

  const S = phase === 'single' ? V * I : Math.sqrt(3) * V * I;
  const P = S * pf;
  const Qmag = S * Math.sqrt(Math.max(0, 1 - pf * pf));
  const Q = loadType === 'leading' ? -Qmag : Qmag;
  const phi = Math.acos(pf) * 180 / Math.PI;

  if (![S, P, Q].every(Number.isFinite)) {
    return showResult('acPowerResult', 'Sonuç hesaplanamadı.', true);
  }

  showResult('acPowerResult', `Faz Tipi: ${phase === 'single' ? 'Tek Faz' : 'Üç Faz (Dengeli)'}
Yük Karakteri: ${loadType === 'leading' ? 'Kapasitif (ileri)' : 'Endüktif (geri)'}
Görünür Güç (S): ${formatNumber(S)} VA
Aktif Güç (P): ${formatNumber(P)} W
Reaktif Güç (Q): ${formatNumber(Q)} var
Güç Faktörü: ${formatNumber(pf)}
Faz Açısı: ${formatNumber(phi)}°`);
}

// ========================================
// 6 - KOMPANZASYON
// ========================================
function selectCapacitorStages(requiredVar) {
  const unitVar = 2500;
  const requiredUnits = Math.ceil(requiredVar / unitVar);

  if (requiredUnits > 50) return null;

  for (let total = requiredUnits; total <= 50; total++) {
    let best = null;

    function search(start, count, remaining, stages) {
      if (count === 0) {
        if (remaining === 0) {
          const balance = stages.reduce(
            (sum, value) => sum + value * value, 0
          );

          if (!best || balance < best.balance) {
            best = { stages: [...stages], balance };
          }
        }
        return;
      }

      for (let value = start; value <= 10; value++) {
        const left = remaining - value;

        if (left < count - 1 || left > (count - 1) * 10) continue;

        search(value, count - 1, left, [...stages, value]);
      }
    }

    search(1, 5, total, []);

    if (best) {
      return {
        stages: best.stages.map(value => value * 2.5),
        totalKvar: total * 2.5
      };
    }
  }

  return null;
}


function calculateHarmonicAnalysis() {
    const fundamentalCurrent = Number(getElement('harmonicFundamentalCurrent')?.value);
    const fundamentalVoltage = Number(getElement('harmonicFundamentalVoltage')?.value);

    if (
        !Number.isFinite(fundamentalCurrent) ||
        !Number.isFinite(fundamentalVoltage) ||
        fundamentalCurrent <= 0 ||
        fundamentalVoltage <= 0
    ) {
        showResult('harmonicAnalysisResult', 'Temel akım ve gerilim sıfırdan büyük olmalıdır.', 'error');
        return;
    }

    const harmonicOrders = [3, 5, 7, 11, 13];

    let currentSquareSum = 0;
    let voltageSquareSum = 0;
    let spectrumHTML = '';

const spectrumData = [];


    for (const order of harmonicOrders) {
        const current = Number(getElement(`harmonic${order}`)?.value ?? 0);
        const voltage = Number(getElement(`harmonicVoltage${order}`)?.value ?? 0);

        if (
            !Number.isFinite(current) ||
            !Number.isFinite(voltage) ||
            current < 0 ||
            voltage < 0
        ) {
            showResult('harmonicAnalysisResult', 'Harmonik değerleri negatif olamaz.', 'error');
            return;
        }

        currentSquareSum += current ** 2;
        voltageSquareSum += voltage ** 2;

        const currentPercent = current / fundamentalCurrent * 100;
        const voltagePercent = voltage / fundamentalVoltage * 100;

spectrumData.push({
    order,
    currentPercent,
    voltagePercent
});


        spectrumHTML += `
            <tr>
                <td>${order}.</td>
                <td>${(50 * order).toFixed(0)} Hz</td>
                <td>${current.toFixed(3)} A</td>
                <td>%${currentPercent.toFixed(2)}</td>
                <td>${voltage.toFixed(3)} V</td>
                <td>%${voltagePercent.toFixed(2)}</td>
            </tr>
        `;
    }

    const thdi = Math.sqrt(currentSquareSum) / fundamentalCurrent * 100;
    const thdv = Math.sqrt(voltageSquareSum) / fundamentalVoltage * 100;

    const totalCurrent = Math.sqrt(fundamentalCurrent ** 2 + currentSquareSum);
    const totalVoltage = Math.sqrt(fundamentalVoltage ** 2 + voltageSquareSum);

const maxCurrentPercent = Math.max(
    1,
    ...spectrumData.map(item => item.currentPercent)
);

const maxVoltagePercent = Math.max(
    1,
    ...spectrumData.map(item => item.voltagePercent)
);

const currentChartHTML = spectrumData.map(item => `
    <div style="margin: 12px 0;">
        <div style="display:flex; justify-content:space-between; margin-bottom:5px;">
            <strong>${item.order}. Harmonik</strong>
            <span>%${item.currentPercent.toFixed(2)}</span>
        </div>
        <div style="height:12px; background:var(--border-color, #e5e7eb); border-radius:8px; overflow:hidden;">
            <div style="height:100%; width:${item.currentPercent / maxCurrentPercent * 100}%; background:#3b82f6; border-radius:8px;"></div>
        </div>
    </div>
`).join('');

const voltageChartHTML = spectrumData.map(item => `
    <div style="margin: 12px 0;">
        <div style="display:flex; justify-content:space-between; margin-bottom:5px;">
            <strong>${item.order}. Harmonik</strong>
            <span>%${item.voltagePercent.toFixed(2)}</span>
        </div>
        <div style="height:12px; background:var(--border-color, #e5e7eb); border-radius:8px; overflow:hidden;">
            <div style="height:100%; width:${item.voltagePercent / maxVoltagePercent * 100}%; background:#16a34a; border-radius:8px;"></div>
        </div>
    </div>
`).join('');

    const result = `
        <h3>Harmonik Analiz Sonuçları</h3>

        <p>Temel akım: <strong>${fundamentalCurrent.toFixed(2)} A</strong></p>
        <p>Toplam RMS akım: <strong>${totalCurrent.toFixed(3)} A</strong></p>
        <p>THDi: <strong>%${thdi.toFixed(2)}</strong></p>

        <hr>

        <p>Temel gerilim: <strong>${fundamentalVoltage.toFixed(2)} V</strong></p>
        <p>Toplam RMS gerilim: <strong>${totalVoltage.toFixed(3)} V</strong></p>
        <p>THDv: <strong>%${thdv.toFixed(2)}</strong></p>

        <h4>Harmonik Spektrumu</h4>

<div style="display:grid; grid-template-columns:repeat(auto-fit,minmax(250px,1fr)); gap:20px; margin:20px 0;">

    <div style="padding:15px; border:1px solid var(--border-color, #ddd); border-radius:12px;">
        <h4>Akım Harmonik Grafiği</h4>
        ${currentChartHTML}
    </div>

    <div style="padding:15px; border:1px solid var(--border-color, #ddd); border-radius:12px;">
        <h4>Gerilim Harmonik Grafiği</h4>
        ${voltageChartHTML}
    </div>

</div>

        <div style="overflow-x:auto;">
            <table>
                <thead>
                    <tr>
                        <th>Harmonik</th>
                        <th>Frekans</th>
                        <th>Akım</th>
                        <th>Akım (%)</th>
                        <th>Gerilim</th>
                        <th>Gerilim (%)</th>
                    </tr>
                </thead>
                <tbody>
                    ${spectrumHTML}
                </tbody>
            </table>
        </div>

        <small>50 Hz temel frekans varsayılmıştır. THDi ve THDv yalnızca girilen 3., 5., 7., 11. ve 13. harmonik bileşenleri üzerinden hesaplanır.</small>
    `;

    showResult('harmonicAnalysisResult', result);
}



function calculateHarmonicFilter() {
    const frequency = Number(getElement('filterFrequency')?.value);
    const harmonicOrder = Number(getElement('filterHarmonicOrder')?.value);
    const capacitanceMicro = Number(getElement('filterCapacitance')?.value);
    const voltage = Number(getElement('filterVoltage')?.value);

    if (
        !Number.isFinite(frequency) ||
        !Number.isFinite(capacitanceMicro) ||
        !Number.isFinite(voltage) ||
        frequency <= 0 ||
        capacitanceMicro <= 0 ||
        voltage <= 0 ||
        ![3, 5, 7, 11, 13].includes(harmonicOrder)
    ) {
        showResult(
            'harmonicFilterResult',
            'Frekans, kapasite ve gerilim değerlerini kontrol ediniz.',
            'error'
        );
        return;
    }

    const capacitance = capacitanceMicro * 1e-6;
    const targetFrequency = frequency * harmonicOrder;

    // Gerekli filtre endüktansı
    const inductance = 1 / (
        (2 * Math.PI * targetFrequency) ** 2 * capacitance
    );

    const inductanceMilli = inductance * 1000;

    // Temel frekanstaki reaktanslar
    const capacitiveReactance = 1 / (
        2 * Math.PI * frequency * capacitance
    );

    const inductiveReactance = (
        2 * Math.PI * frequency * inductance
    );

    // Ayar frekansındaki reaktanslar
    const tunedCapacitiveReactance = 1 / (
        2 * Math.PI * targetFrequency * capacitance
    );

    const tunedInductiveReactance = (
        2 * Math.PI * targetFrequency * inductance
    );

    // Tek faz eşdeğer kondansatör reaktif gücü
    const reactivePower = (
        voltage ** 2 / capacitiveReactance
    );

    const reactivePowerKvar = reactivePower / 1000;

    // Gerçek rezonans frekansı
    const actualResonance = 1 / (
        2 * Math.PI * Math.sqrt(inductance * capacitance)
    );

    const result = `
        <h3>LC Filtre Tasarım Sonuçları</h3>

        <h4>Temel Tasarım Parametreleri</h4>
        <p>Şebeke frekansı: <strong>${frequency.toFixed(2)} Hz</strong></p>
        <p>Hedef harmonik: <strong>${harmonicOrder}. harmonik</strong></p>
        <p>Filtre ayar frekansı: <strong>${targetFrequency.toFixed(2)} Hz</strong></p>
        <p>Kondansatör kapasitesi: <strong>${capacitanceMicro.toFixed(2)} µF</strong></p>
        <p>Kondansatör gerilimi: <strong>${voltage.toFixed(2)} V</strong></p>

        <hr>

        <h4>Bobin ve Kondansatör Hesapları</h4>
        <p>Gerekli bobin endüktansı: <strong>${inductanceMilli.toFixed(3)} mH</strong></p>
        <p>Temel frekansta bobin reaktansı (XL): <strong>${inductiveReactance.toFixed(3)} Ω</strong></p>
        <p>Temel frekansta kondansatör reaktansı (XC): <strong>${capacitiveReactance.toFixed(3)} Ω</strong></p>

        <hr>

        <h4>Harmonik Ayar Frekansındaki Reaktanslar</h4>
        <p>Bobin reaktansı: <strong>${tunedInductiveReactance.toFixed(3)} Ω</strong></p>
        <p>Kondansatör reaktansı: <strong>${tunedCapacitiveReactance.toFixed(3)} Ω</strong></p>

        <hr>

        <h4>Reaktif Güç ve Rezonans</h4>
        <p>Kondansatör reaktif gücü: <strong>${reactivePowerKvar.toFixed(4)} kVAr</strong></p>
        <p>Hesaplanan rezonans frekansı: <strong>${actualResonance.toFixed(2)} Hz</strong></p>

        <small>
            Reaktif güç hesabı tek faz eşdeğer kondansatör için yapılmıştır.
            Üç fazlı sistemlerde bağlantı şekli ve faz gerilimi dikkate alınmalıdır.
            Bu hesap ideal tek ayarlı LC filtre hesabıdır. Gerçek uygulamada
            harmonik akımlar, şebeke empedansı, kondansatör ve reaktör anma
            değerleri, sönümleme ve rezonans riski ayrıca incelenmelidir.
        </small>
    `;

    showResult('harmonicFilterResult', result);
}


function calculateCompensation() {
  const phase = getElement('compensationPhase')?.value;
  const PkW = getNumber('compensationPower');
  const pf1 = getNumber('compensationCurrentPF');
  const pf2 = getNumber('compensationTargetPF');
  const V = getNumber('compensationVoltage');
  const f = getNumber('compensationFrequency');
  const connection = getElement('compensationConnection')?.value;

  const values = [PkW, pf1, pf2, V, f];

  if (values.some(v => v === null)) {
    return showResult('compensationResult', 'Tüm hesaplama değerlerini gir.', true);
  }

  if (!['single', 'three'].includes(phase)) {
    return showResult('compensationResult', 'Geçerli faz tipi seç.', true);
  }

  if (PkW <= 0 || V <= 0 || f <= 0) {
    return showResult('compensationResult', 'Aktif güç, gerilim ve frekans pozitif olmalıdır.', true);
  }

  if (pf1 <= 0 || pf1 > 1 || pf2 <= 0 || pf2 > 1 || pf2 <= pf1) {
    return showResult('compensationResult', 'Güç faktörleri 0-1 aralığında olmalı ve hedef değer mevcut değerden büyük olmalıdır.', true);
  }

  if (phase === 'three' && !['delta', 'star'].includes(connection)) {
    return showResult('compensationResult', 'Üç faz kondansatör bağlantısını seç.', true);
  }

  const P = PkW * 1000;
  const Q1 = P * Math.tan(Math.acos(pf1));
  const Q2 = P * Math.tan(Math.acos(pf2));
  const Qc = Q1 - Q2;
  const omega = 2 * Math.PI * f;

  let C;

  if (phase === 'single') {
    C = Qc / (omega * V * V);
  } else if (connection === 'delta') {
    C = Qc / (3 * omega * V * V);
  } else {
    C = Qc / (omega * V * V);
  }

  const uF = C * 1e6;

  if (![Q1, Q2, Qc, C, uF].every(Number.isFinite) || C <= 0) {
    return showResult('compensationResult', 'Hesaplama sonucu geçersiz.', true);
  }

   const stagePlan = selectCapacitorStages(Qc);

  const stageText = stagePlan
    ? stagePlan.stages.map((value, index) =>
        `Kademe ${index + 1}: ${formatNumber(value)} kvar`
      ).join('\n')
    : '5 kademeli standart kondansatör bankası için uygun kapasite bulunamadı.';

  const stageTotal = stagePlan ? stagePlan.totalKvar : null;

  showResult('compensationResult', `Mevcut Reaktif Güç: ${formatNumber(Q1 / 1000)} kvar
Hedef Reaktif Güç: ${formatNumber(Q2 / 1000)} kvar
Gerekli Kondansatör Gücü: ${formatNumber(Qc / 1000)} kvar

Bağlantı: ${phase === 'single' ? 'Tek Faz' : connection === 'delta' ? 'Üçgen (Δ)' : 'Yıldız (Y)'}
Faz Başına Kapasitans: ${formatNumber(uF)} µF

OTOMATİK KONDANSATÖR KADEME ÖNERİSİ
${stageText}
Önerilen Toplam Güç: ${stageTotal !== null ? formatNumber(stageTotal) + ' kvar' : 'Hesaplanamadı'}
${stageTotal !== null ? 'Kapasite Farkı: ' + formatNumber(stageTotal - Qc / 1000) + ' kvar' : ''}

Not: Üç faz hesabında gerilim hatlar arası RMS değeridir. Kapasitans faz başına verilmiştir. Kademe önerisi teoriktir; saha koşulları ve harmonikler ayrıca değerlendirilmelidir.`);
}

// ========================================
// 7 - KONDANSATÖR
// ========================================

function calculateCapacitorReactance() {
  const f = getNumber('capacitorFrequency');
  const uF = getNumber('capacitorValue');

  if (!positiveValues([f, uF])) {
    return showResult('capacitorReactanceResult', 'Frekans ve kapasitans pozitif olmalıdır.', true);
  }

  const Xc = 1 / (2 * Math.PI * f * uF * 1e-6);

  if (!Number.isFinite(Xc)) {
    return showResult('capacitorReactanceResult', 'Sonuç hesaplanamadı.', true);
  }

  showResult('capacitorReactanceResult', `Frekans: ${formatNumber(f)} Hz
Kapasitans: ${formatNumber(uF)} µF
Kapasitif Reaktans: ${formatNumber(Xc)} Ω`);
}

function calculateCapacitorCharge() {
  const uF = getNumber('chargeCapacitance');
  const V = getNumber('chargeVoltage');

  if (uF === null || V === null || uF <= 0 || V < 0) {
    return showResult('capacitorChargeResult', 'Pozitif kapasitans ve negatif olmayan gerilim gir.', true);
  }

  const q = uF * 1e-6 * V;

  showResult('capacitorChargeResult', `Kapasitans: ${formatNumber(uF)} µF
Gerilim: ${formatNumber(V)} V
Elektrik Yükü: ${formatNumber(q)} C
Elektrik Yükü: ${formatNumber(q * 1e6)} µC`);
}

// ========================================
// 8 - BOBİN
// ========================================

function calculateInductor() {
  const f = getNumber('inductorFrequency');
  const mH = getNumber('inductorValue');

  if (!positiveValues([f, mH])) {
    return showResult('inductorResult', 'Frekans ve endüktans pozitif olmalıdır.', true);
  }

  const XL = 2 * Math.PI * f * mH * 1e-3;

  showResult('inductorResult', `Frekans: ${formatNumber(f)} Hz
Endüktans: ${formatNumber(mH)} mH
Endüktif Reaktans: ${formatNumber(XL)} Ω`);
}

// ========================================
// 9 - SERİ RLC EMPEDANSI
// ========================================

function calculateImpedance() {
  const R = getNumber('impedanceResistance');
  const mH = getNumber('impedanceInductance');
  const uF = getNumber('impedanceCapacitance');
  const f = getNumber('impedanceFrequency');

  if ([R, mH, uF, f].some(v => v === null) || R < 0 || mH <= 0 || uF <= 0 || f <= 0) {
    return showResult('impedanceResult', 'Direnç negatif olamaz; L, C ve frekans pozitif olmalıdır.', true);
  }

  const XL = 2 * Math.PI * f * mH * 1e-3;
  const XC = 1 / (2 * Math.PI * f * uF * 1e-6);
  const X = XL - XC;
  const Z = Math.hypot(R, X);
  const angle = Math.atan2(X, R) * 180 / Math.PI;
  const pf = Z === 0 ? 1 : R / Z;

  showResult('impedanceResult', `Endüktif Reaktans (XL): ${formatNumber(XL)} Ω
Kapasitif Reaktans (XC): ${formatNumber(XC)} Ω
Net Reaktans (X): ${formatNumber(X)} Ω
Toplam Empedans (Z): ${formatNumber(Z)} Ω
Faz Açısı: ${formatNumber(angle)}°
Güç Faktörü: ${formatNumber(pf)}
Devre Karakteri: ${X > 0 ? 'Endüktif' : X < 0 ? 'Kapasitif' : 'Rezonans / direnç ağırlıklı'}`);
}

// ========================================
// 10 - REZONANS
// ========================================

function calculateResonance() {
  const mH = getNumber('resonanceInductance');
  const uF = getNumber('resonanceCapacitance');

  if (!positiveValues([mH, uF])) {
    return showResult('resonanceResult', 'Endüktans ve kapasitans pozitif olmalıdır.', true);
  }

  const L = mH * 1e-3;
  const C = uF * 1e-6;
  const f0 = 1 / (2 * Math.PI * Math.sqrt(L * C));

  showResult('resonanceResult', `Endüktans: ${formatNumber(mH)} mH
Kapasitans: ${formatNumber(uF)} µF
Rezonans Frekansı: ${formatNumber(f0)} Hz
Açısal Rezonans Frekansı: ${formatNumber(2 * Math.PI * f0)} rad/s`);
}// ========================================
// 11 - TEMEL TRANSFORMATÖR
// ========================================

function calculateTransformer() {
  const V1 = getNumber('primaryVoltage');
  const V2 = getNumber('secondaryVoltage');
  const N1 = getNumber('primaryTurns');
  const N2 = getNumber('secondaryTurns');
  const I1 = getNumber('primaryCurrent');
  const eta = getNumber('transformerEfficiency');

  if ([V1, V2, N1, N2, I1, eta].some(v => v === null)) {
    return showResult('transformerResult', 'Bütün transformatör parametrelerini gir.', true);
  }

  if (V1 <= 0 || V2 <= 0 || N1 <= 0 || N2 <= 0 || I1 < 0 || eta <= 0 || eta > 100) {
    return showResult('transformerResult', 'Gerilim ve sarım pozitif, akım negatif olmayan ve verim %0-100 arasında olmalıdır.', true);
  }

  const S1 = V1 * I1;
  const S2 = S1 * eta / 100;
  const I2 = S2 / V2;
  const loss = S1 - S2;
  const vr = V1 / V2;
  const tr = N1 / N2;
  const diff = Math.abs(vr - tr) / tr * 100;

  const type = V2 > V1 ? 'Yükseltici' : V2 < V1 ? 'Düşürücü' : '1:1';

  showResult('transformerResult', `Transformatör Tipi: ${type}
Gerilim Oranı (V1/V2): ${formatNumber(vr)}
Sarım Oranı (N1/N2): ${formatNumber(tr)}

Primer Görünür Gücü: ${formatNumber(S1)} VA
Tahmini Sekonder Görünür Gücü: ${formatNumber(S2)} VA
Primer Akımı: ${formatNumber(I1)} A
Tahmini Sekonder Akımı: ${formatNumber(I2)} A

Verim: %${formatNumber(eta)}
Tahmini Kayıp: ${formatNumber(loss)} VA eşdeğeri
Oran Farkı: %${formatNumber(diff)}

Not: Basit hesapta güç faktörü 1 kabul edilmiştir. V×I görünür güçtür (VA).`);
}

// ========================================
// 12 - BOŞTA DENEY
// ========================================

function calculateOpenCircuit() {
  const V = getNumber('ocVoltage');
  const I = getNumber('ocCurrent');
  const P = getNumber('ocPower');

  if (!positiveValues([V, I, P])) {
    return showResult('ocResult', 'Boşta deney gerilimi, akımı ve gücü pozitif olmalıdır.', true);
  }

  const S = V * I;

  if (P > S * (1 + 1e-10)) {
    return showResult('ocResult', 'Boşta aktif güç görünür güçten büyük olamaz.', true);
  }

  const Iv = P / V;
  const Im2 = I * I - Iv * Iv;

  if (Im2 < -1e-9) {
    return showResult('ocResult', 'Boşta deney verileri fiziksel olarak tutarsız.', true);
  }

  const Im = Math.sqrt(Math.max(0, Im2));

  if (Im < 1e-12) {
    return showResult('ocResult', 'Mıknatıslanma akımı sıfıra çok yakın.', true);
  }

  showResult('ocResult', `Boşta Görünür Güç: ${formatNumber(S)} VA
Demir Kaybı: ${formatNumber(P)} W
Boşta Güç Faktörü: ${formatNumber(P / S)}
Aktif Akım Bileşeni: ${formatNumber(Iv)} A
Mıknatıslanma Akımı: ${formatNumber(Im)} A
Demir Kayıp Direnci (R0): ${formatNumber(V * V / P)} Ω
Mıknatıslanma Reaktansı (Xm): ${formatNumber(V / Im)} Ω

Not: Tek faz ölçümü ve ölçüm yapılan tarafa göre eşdeğer devre değerleridir.`);
}

// ========================================
// 13 - KISA DEVRE DENEYİ
// ========================================


function calculateTransformerShortCircuitTest() {
  const voltageInput = document.getElementById('transformerScVoltage');
  const currentInput = document.getElementById('scCurrent');
  const powerInput = document.getElementById('scPower');
  const result = document.getElementById('scResult');

  if (!voltageInput || !currentInput || !powerInput || !result) {
    console.error('Kısa devre deneyi HTML elemanları bulunamadı.');
    return;
  }

  const V = Number(voltageInput.value);
  const I = Number(currentInput.value);
  const P = Number(powerInput.value);

  if (
    voltageInput.value.trim() === '' ||
    currentInput.value.trim() === '' ||
    powerInput.value.trim() === ''
  ) {
    result.textContent = 'Lütfen tüm deney değerlerini gir.';
    result.classList.add('error');
    return;
  }

  if (
    !Number.isFinite(V) ||
    !Number.isFinite(I) ||
    !Number.isFinite(P) ||
    V <= 0 ||
    I <= 0 ||
    P < 0
  ) {
    result.textContent = 'Gerilim ve akım sıfırdan büyük, güç ise sıfır veya daha büyük olmalıdır.';
    result.classList.add('error');
    return;
  }

  const S = V * I;
  const Z = V / I;
  const R = P / (I * I);
  const x2 = Z * Z - R * R;

  if (P > S) {
    result.textContent = 'Hata: Aktif güç, görünür güçten büyük olamaz. Ölçüm değerlerini kontrol et.';
    result.classList.add('error');
    return;
  }

  if (x2 < -1e-9) {
    result.textContent = 'Hata: Girilen ölçümler fiziksel olarak geçerli bir eşdeğer reaktans vermiyor.';
    result.classList.add('error');
    return;
  }

  const X = Math.sqrt(Math.max(0, x2));
  const powerFactor = P / S;

  const fmt = value => Number(value).toLocaleString('tr-TR', {
    maximumFractionDigits: 4
  });

  showResult('scResult', `
    <strong>KISA DEVRE DENEYİ SONUÇLARI</strong><br><br>
    Görünür Güç (S): ${fmt(S)} VA<br>
    Bakır Kaybı (Psc): ${fmt(P)} W<br>
    Güç Faktörü (cosφ): ${fmt(powerFactor)}<br>
    Eşdeğer Empedans (Zeq): ${fmt(Z)} Ω<br>
    Eşdeğer Direnç (Req): ${fmt(R)} Ω<br>
    Eşdeğer Reaktans (Xeq): ${fmt(X)} Ω<br><br>
    <em>Not: Tek fazlı kısa devre deneyi bağıntıları kullanılmıştır. Hesaplanan parametreler ölçüm yapılan tarafa aittir.</em>
    `);
}


// ========================================
// 14 - TRANSFORMATÖR YÜK PERFORMANSI
// ========================================

function calculateTransformerPerformance() {
  const V0 = getNumber('ocVoltage');
  const I0 = getNumber('ocCurrent');
  const P0 = getNumber('ocPower');
  const Vsc = getNumber('transformerScVoltage');
  const Isc = getNumber('scCurrent');
  const Psc = getNumber('scPower');
  const Srate = getNumber('ratedPower');
  const Vrate = getNumber('ratedSecondaryVoltage');
  const loadPct = getNumber('loadPercentage');
  const pf = getNumber('loadPowerFactor');
  const loadType = getElement('loadType')?.value || 'lagging';
const scReferenceSide = getElement('scReferenceSide')?.value || 'secondary';

const N1 = getNumber('primaryTurns');
const N2 = getNumber('secondaryTurns');
  const vals = [V0, I0, P0, Vsc, Isc, Psc, Srate, Vrate, loadPct, pf];

  if (vals.some(v => v === null)) {
    return showResult('performanceResult', 'Boşta ve kısa devre deneyleri ile anma/yük değerlerinin tamamını gir.', true);
  }

  if (!positiveValues([V0, I0, P0, Vsc, Isc, Psc, Srate, Vrate]) ||
      loadPct <= 0 || loadPct > 150 || pf <= 0 || pf > 1) {
    return showResult('performanceResult', 'Deney ve anma değerleri pozitif olmalı; yük oranı %0-150, güç faktörü 0-1 aralığında olmalıdır.', true);
  }

  if (P0 > V0 * I0 || Psc > Vsc * Isc) {
    return showResult('performanceResult', 'Deney aktif güçleri görünür güçlerden büyük olamaz.', true);
  }

  const Iv = P0 / V0;
  const Im2 = I0 * I0 - Iv * Iv;

  if (Im2 < -1e-9) {
    return showResult('performanceResult', 'Boşta deney verileri fiziksel olarak tutarsız.', true);
  }
let IscRef = Isc;
 let Z = Vsc / Isc;
let R = Psc / (Isc * Isc);
let X = Math.sqrt(Math.max(0, Z * Z - R * R));

if (scReferenceSide === 'primary') {
  if (N1 === null || N2 === null || N1 <= 0 || N2 <= 0) {
    return showResult('performanceResult', 'Primer tarafı seçildiğinde geçerli primer ve sekonder sarım sayıları girilmelidir.', true);
  }

  const turnsRatioSquared = (N2 / N1) ** 2;

  Z *= turnsRatioSquared;
  R *= turnsRatioSquared;
  X *= turnsRatioSquared;
  IscRef *= N1 / N2;
}

  const fraction = loadPct / 100;
  const Irated = Srate / Vrate;
  const Iload = Irated * fraction;

  const copperLoss = Psc * (Iload / IscRef) ** 2;
  const ironLoss = P0;
  const Pout = Srate * fraction * pf;
  const loss = copperLoss + ironLoss;
  const Pin = Pout + loss;
  const eta = Pin > 0 ? 100 * Pout / Pin : 0;

  const sinPhi = Math.sqrt(Math.max(0, 1 - pf * pf));
  const drop = Iload * (R * pf + (loadType === 'leading' ? -1 : 1) * X * sinPhi);
  const reg = 100 * drop / Vrate;
  const Vterminal = Vrate - drop;

  showResult('performanceResult', `YÜK BİLGİLERİ
Anma Görünür Gücü: ${formatNumber(Srate)} VA
Anma Sekonder Gerilimi: ${formatNumber(Vrate)} V
Anma Akımı: ${formatNumber(Irated)} A
Yük Akımı: ${formatNumber(Iload)} A
Kısa Devre Deney Akımı: ${formatNumber(Isc)} A
Yüklenme Oranı: %${formatNumber(loadPct)}

GÜÇ VE KAYIPLAR
Çıkış Aktif Gücü: ${formatNumber(Pout)} W
Demir Kaybı: ${formatNumber(ironLoss)} W
Bakır Kaybı: ${formatNumber(copperLoss)} W
Toplam Kayıp: ${formatNumber(loss)} W
Tahmini Giriş Aktif Gücü: ${formatNumber(Pin)} W

PERFORMANS
Tahmini Verim: %${formatNumber(eta)}
Gerilim Düşümü: ${formatNumber(drop)} V
Gerilim Regülasyonu: %${formatNumber(reg)}
Tahmini Sekonder Gerilimi: ${formatNumber(Vterminal)} V

EŞDEĞER DEVRE
Req: ${formatNumber(R)} Ω
Xeq: ${formatNumber(X)} Ω
Zeq: ${formatNumber(Z)} Ω

Not: Psc ve Isc aynı sargı tarafına ait olmalıdır. Req/Xeq sekonder tarafına indirgenmiş olmalıdır.`);
}// ========================================
// 15 - KABLO HESAPLARI
// ========================================

const STANDARD_CABLE_SECTIONS = [
  1.5, 2.5, 4, 6, 10, 16, 25, 35, 50,
  70, 95, 120, 150, 185, 240, 300, 400
];

function cableResistivity(material) {
  return material === 'aluminum' ? 0.0282 : 0.0175;
}

function calculateCableSizing() {
  const I = getNumber('cableSizingCurrent');
  const J = getNumber('cableCurrentDensity');
  const material = getElement('cableSizingMaterial').value;

  if (I === null || J === null || I <= 0 || J <= 0) {
    return showResult('cableSizingResult', 'Yük akımı ve akım yoğunluğu pozitif olmalıdır.', true);
  }

  const theoretical = I / J;
  const selected = STANDARD_CABLE_SECTIONS.find(s => s >= theoretical);

  showResult('cableSizingResult', `İletken: ${material === 'copper' ? 'Bakır' : 'Alüminyum'}
Yük Akımı: ${formatNumber(I)} A
Akım Yoğunluğu: ${formatNumber(J)} A/mm²
Teorik Kesit: ${formatNumber(theoretical)} mm²
Önerilen Standart Kesit: ${selected ? selected + ' mm²' : '400 mm² üzerinde - özel tasarım gerekli'}

Uyarı: Bu yalnızca ön kesit seçimidir. Akım taşıma kapasitesi, gerilim düşümü, kısa devre dayanımı ve koruma koordinasyonu ayrıca doğrulanmalıdır.`);
}

function calculateCableCapacity() {
  const S = getNumber('cableCapacitySection');
  const J = getNumber('cableCapacityDensity');
  const kt = getNumber('cableTemperatureFactor');
  const kg = getNumber('cableGroupingFactor');
  const ki = getNumber('cableInstallationFactor');
  const material = getElement('cableCapacityMaterial').value;

  if ([S, J, kt, kg, ki].some(v => v === null)) {
    return showResult('cableCapacityResult', 'Tüm kapasite ve düzeltme değerlerini gir.', true);
  }

  if (S <= 0 || J <= 0 || [kt, kg, ki].some(v => v <= 0 || v > 1)) {
    return showResult('cableCapacityResult', 'Kesit ve akım yoğunluğu pozitif; düzeltme katsayıları 0-1 arasında olmalıdır.', true);
  }

  const materialFactor = material === 'aluminum' ? 0.78 : 1;
  const base = S * J * materialFactor;
  const corrected = base * kt * kg * ki;

  showResult('cableCapacityResult', `İletken: ${material === 'copper' ? 'Bakır' : 'Alüminyum'}
Kesit: ${formatNumber(S)} mm²
Yaklaşık temel kapasite: ${formatNumber(base)} A
Sıcaklık katsayısı: ${formatNumber(kt)}
Gruplama katsayısı: ${formatNumber(kg)}
Döşeme katsayısı: ${formatNumber(ki)}
Düzeltilmiş yaklaşık kapasite: ${formatNumber(corrected)} A

Not: Akım yoğunluğu yaklaşımıdır; standart akım taşıma tablolarının yerine geçmez.`);
}

function calculateVoltageDrop() {
  const phase = getElement('voltageDropPhase').value;
  const V = getNumber('voltageDropVoltage');
  const I = getNumber('voltageDropCurrent');
  const L = getNumber('voltageDropLength');
  const S = Number(getElement('voltageDropSection').value);
  const pf = getNumber('voltageDropPF');
  const Xkm = getNumber('voltageDropReactance');
  const material = getElement('voltageDropMaterial').value;

  if ([V, I, L, pf, Xkm].some(v => v === null)) {
    return showResult('voltageDropResult', 'Gerilim, akım, uzunluk, güç faktörü ve reaktans değerlerini gir.', true);
  }

  if (V <= 0 || I < 0 || L < 0 || S <= 0 || pf < 0 || pf > 1 || Xkm < 0) {
    return showResult('voltageDropResult', 'Gerilim ve kesit pozitif; akım, uzunluk ve reaktans negatif olmayan; güç faktörü 0-1 arasında olmalıdır.', true);
  }

  const rho = cableResistivity(material);
  const Rkm = rho * 1000 / S;
  const sinPhi = Math.sqrt(Math.max(0, 1 - pf * pf));
  const factor = phase === 'three' ? Math.sqrt(3) : 2;

  const drop = factor * (L / 1000) * I * (Rkm * pf + Xkm * sinPhi);
  const percent = 100 * drop / V;
  const receiving = V - drop;

  showResult('voltageDropResult', `Faz Tipi: ${phase === 'three' ? 'Dengeli üç faz' : 'Tek faz'}
İletken: ${material === 'copper' ? 'Bakır' : 'Alüminyum'}
Kesit: ${formatNumber(S)} mm²
Tek yön uzunluk: ${formatNumber(L)} m
Hesaplanan direnç: ${formatNumber(Rkm)} Ω/km
Reaktans: ${formatNumber(Xkm)} Ω/km
Gerilim düşümü: ${formatNumber(drop)} V
Gerilim düşümü oranı: %${formatNumber(percent)}
Yaklaşık alıcı uç gerilimi: ${formatNumber(receiving)} V

Not: İletken direnci yaklaşık 20 °C değerindedir. Çalışma sıcaklığı ve gerçek kablo reaktansı ayrıca dikkate alınmalıdır.`);
}

// ========================================
// 16 - HESAPLAMA GEÇMİŞİ
// ========================================

const HISTORY_KEY = 'elektrikLabHistory_v2';


const RESULT_TITLES = {
  ohmResult: 'Ohm Kanunu',
  powerResult: 'DC Güç',
  resistanceResult: 'Direnç Hesaplama',
  convertResult: 'Birim Dönüştürme',
  acPowerResult: 'AC Güç',
  compensationResult: 'Kompanzasyon',
  capacitorReactanceResult: 'Kondansatör Reaktansı',
  capacitorChargeResult: 'Kondansatör Yükü',
  inductorResult: 'Bobin Reaktansı',
  impedanceResult: 'Empedans',
  resonanceResult: 'Rezonans',
  transformerResult: 'Transformatör',
  ocResult: 'Boşta Deney',
  scResult: 'Kısa Devre Deneyi',
  performanceResult: 'Trafo Performansı',
  cableSizingResult: 'Kablo Kesiti',
  cableCapacityResult: 'Kablo Akım Kapasitesi',
  voltageDropResult: 'Gerilim Düşümü',
  threePhaseResult: 'Üç Faz Güç Analizi',
  motorResult: 'Asenkron Motor Performansı',
  motorStartingResult: 'Motor Kalkış ve Yol Verme Analizi',
  mechanicalMotorResult: 'Motor Mekanik Güç ve Tork',
  singleMotorResult: 'Tek Fazlı Motor Akım Analizi',
  shortCircuitResult: 'Üç Fazlı Kısa Devre Hesabı',
  scTransformerResult: 'Transformatör Kısa Devre Hesabı',
  scCableResult: 'Kablo Empedansına Göre Kısa Devre Hesabı',
  breakerCheckResult: 'Sigorta ve Devre Kesici Uygunluk Kontrolü',
  generatorPowerResult: 'Jeneratör Güç Hesabı',
generatorCurrentResult: 'Jeneratör Anma Akımı Hesabı',
generatorLoadResult: 'Jeneratör Yüklenme Analizi',
generatorEfficiencyResult: 'Jeneratör Verim Hesabı',
earthRodResult: 'Düşey Topraklama Elektrodu Direnci',
earthConductorResult: 'Koruma İletkeni Kesit Hesabı',
rcdCheckResult: 'Kaçak Akım Rölesi Uygunluk Kontrolü',
earthingSystemResult: 'TT / TN Topraklama Sistemi Değerlendirmesi',
ieee519Result: 'IEEE 519 Değerlendirmesi',
harmonicAnalysisResult: 'Harmonik Bozulma Analizi',
harmonicFilterResult: 'Pasif LC Filtre Tasarımı'
};


function readHistory() {
  try {
    const data = JSON.parse(localStorage.getItem(HISTORY_KEY) || '[]');
    return Array.isArray(data) ? data : [];
  } catch {
    return [];
  }
}

function writeHistory(items) {
  try {
    localStorage.setItem(HISTORY_KEY, JSON.stringify(items.slice(0, 500)));
  } catch {
    setHistoryMessage('Tarayıcı depolama alanına kayıt yapılamadı.');
  }
}

function setHistoryMessage(message) {
  const el = getElement('historyMessage');
  if (el) el.textContent = message;
}

function saveCalculationHistory(resultId, result) {
  if (!RESULT_TITLES[resultId]) return;

  const resultElement = getElement(resultId);
  const section = resultElement?.closest('.page');
  const inputs = {};

  section?.querySelectorAll('input[id],select[id],textarea[id]').forEach(el => {
    if (el.value !== '') inputs[el.id] = el.value;
  });

  const record = {
    id: `${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    timestamp: new Date().toISOString(),
    module: RESULT_TITLES[resultId],
    resultId,
    result: String(result),
    inputs
  };

  const items = readHistory();
  items.unshift(record);
  writeHistory(items);
  renderHistory();
}

function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, char => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;'
  })[char]);
}

function renderHistory() {
  const list = getElement('historyList');
  if (!list) return;

  const items = readHistory();
  const count = getElement('historyCount');

  if (count) count.textContent = String(items.length);

  if (!items.length) {
    list.innerHTML = `<div class="history-empty">
      <span>◷</span>
      <h3>Henüz hesaplama bulunmuyor</h3>
      <p>Bir hesaplama yaptığında kayıtların burada görünecek.</p>
    </div>`;
    return;
  }

  list.innerHTML = items.map((item, index) => {
    const date = new Date(item.timestamp);
    const dateText = Number.isNaN(date.getTime())
      ? 'Tarih bilinmiyor'
      : date.toLocaleString('tr-TR');

    const inputsText = Object.entries(item.inputs || {})
      .map(([key, value]) => `${key}: ${value}`)
      .join('\n') || 'Kayıtlı giriş değeri yok.';

    return `<article class="history-item">
      <div class="history-item-header">
        <div>
          <strong>${escapeHTML(item.module)}</strong>
          <span>${escapeHTML(dateText)}</span>
        </div>

        <div class="history-item-actions">
          <button type="button" data-history-action="details" data-index="${index}">Detaylar</button>
          <button type="button" data-history-action="restore" data-index="${index}">Geri Yükle</button>
          <button type="button" data-history-action="delete" data-index="${index}">Sil</button>
        </div>
      </div>

      <div class="history-item-body" hidden>
        <pre>${escapeHTML(inputsText)}</pre>
        <div class="history-result">${escapeHTML(item.result)}</div>
      </div>
    </article>`;
  }).join('');
}

function handleHistoryAction(event) {
  const button = event.target.closest('button[data-history-action]');
  if (!button) return;

  const index = Number(button.dataset.index);
  const items = readHistory();
  const item = items[index];

  if (!item) return;

  const action = button.dataset.historyAction;

  if (action === 'details') {
    const body = button.closest('.history-item').querySelector('.history-item-body');
    body.hidden = !body.hidden;
    button.textContent = body.hidden ? 'Detaylar' : 'Gizle';
  }

  if (action === 'delete') {
    items.splice(index, 1);
    writeHistory(items);
    renderHistory();
    setHistoryMessage('Kayıt silindi.');
  }

  if (action === 'restore') {
    const pageMap = {
      'Üç Faz Güç Analizi': 'advanced',
      'Asenkron Motor Performansı': 'advanced',
      'Kablo Kesiti': 'cable',
      'Kablo Akım Kapasitesi': 'cable',
      'Gerilim Düşümü': 'cable',
      'Ohm Kanunu': 'ohm',
      'DC Güç': 'dcPower',
      'Direnç Hesaplama': 'resistance',
      'Birim Dönüştürme': 'converter',
      'AC Güç': 'acPower',
      'Kompanzasyon': 'compensation',
      'Kondansatör Reaktansı': 'capacitor',
      'Kondansatör Yükü': 'capacitor',
      'Bobin Reaktansı': 'inductor',
      'Empedans': 'impedance',
      'Rezonans': 'resonance'
    };

    showPage(pageMap[item.module] || 'transformer');

    Object.entries(item.inputs || {}).forEach(([id, value]) => {
      const el = getElement(id);
      if (el) el.value = value;
    });

    setHistoryMessage('Giriş değerleri geri yüklendi. Hesaplamayı yeniden çalıştırabilirsin.');
  }
}

function exportHistoryCSV() {
  const items = readHistory();

  if (!items.length) {
    return setHistoryMessage('Dışa aktarılacak kayıt bulunmuyor.');
  }

  const rows = [
    ['Tarih', 'Modül', 'Sonuç', 'Giriş Değerleri'],
    ...items.map(item => [
      new Date(item.timestamp).toLocaleString('tr-TR'),
      item.module,
      item.result,
      Object.entries(item.inputs || {})
        .map(([key, value]) => `${key}=${value}`)
        .join('; ')
    ])
  ];

  const csv = '\uFEFF' + rows
    .map(row => row.map(value =>
      '"' + String(value ?? '').replace(/"/g, '""') + '"'
    ).join(';'))
    .join('\r\n');

  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');

  a.href = url;
  a.download = 'elektrik-lab-hesaplama-gecmisi.csv';
  a.click();

  URL.revokeObjectURL(url);
  setHistoryMessage(`${items.length} kayıt CSV olarak dışa aktarıldı.`);
}

function exportHistoryPDF() {
  const items = readHistory();

  if (!items.length) {
    return setHistoryMessage('PDF raporu oluşturulacak kayıt bulunmuyor.');
  }

  const reportWindow = window.open('', '_blank');

  if (!reportWindow) {
    return setHistoryMessage('PDF raporu için açılır pencereye izin vermelisin.');
  }

  const escapeHTML = value => String(value ?? '').replace(/[&<>"']/g, char => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;'
  })[char]);

  const rows = items.map((item, index) => `
    <tr>
      <td>${index + 1}</td>
      <td style="width: 145px; min-width: 145px; white-space: nowrap;">
  ${escapeHTML(new Date(item.timestamp).toLocaleString('tr-TR'))}
</td>
      <td>${escapeHTML(item.module)}</td>
      <td>${escapeHTML(item.result)}</td>
      <td>${escapeHTML(
        Object.entries(item.inputs || {})
          .map(([key, value]) => `${key}: ${value}`)
          .join(' | ')
      )}</td>
    </tr>
  `).join('');

  reportWindow.document.write(`
    <!DOCTYPE html>
    <html lang="tr">
    <head>
      <meta charset="UTF-8">
      <title>Elektrik LAB - Hesaplama Raporu</title>
      <style>
        body {
          font-family: Arial, sans-serif;
          margin: 30px;
          color: #222;
        }
        h1 {
          color: #163b65;
          margin-bottom: 5px;
        }
        .subtitle {
          color: #666;
          margin-bottom: 25px;
        }
        .summary {
          padding: 12px;
          background: #eef4fa;
          margin-bottom: 20px;
        }
        
table {
  width: 100%;
  border-collapse: collapse;
  table-layout: fixed;
  font-size: 10px;
}

th, td {
  border: 1px solid #ccc;
  padding: 7px;
  text-align: left;
  vertical-align: top;
  overflow-wrap: anywhere;
}

th:nth-child(1), td:nth-child(1) {
  width: 5%;
}

th:nth-child(2), td:nth-child(2) {
  width: 17%;
}

th:nth-child(3), td:nth-child(3) {
  width: 13%;
}

th:nth-child(4), td:nth-child(4) {
  width: 30%;
}

th:nth-child(5), td:nth-child(5) {
  width: 35%;
}

th {
  background: #163b65;
  color: white;
}

tr {
  page-break-inside: avoid;
}

@media print {
  body { margin: 15mm; }
  .no-print { display: none; }
}

      </style>
    </head>
    <body>
      <h1>ELEKTRİK LAB</h1>
      <div class="subtitle">Elektrik Mühendisliği Hesaplama Raporu</div>

      <div class="summary">
        <strong>Toplam hesaplama:</strong> ${items.length}<br>
        <strong>Rapor tarihi:</strong> ${escapeHTML(new Date().toLocaleString('tr-TR'))}
      </div>

      <table>
        <thead>
          <tr>
            <th>No</th>
            <th style="width: 115px;">Tarih</th>
            <th>Modül</th>
            <th>Hesaplama Sonucu</th>
            <th>Giriş Değerleri</th>
          </tr>
        </thead>
        <tbody>${rows}</tbody>
      </table>

      <p class="no-print">
        PDF oluşturmak için açılan yazdırma penceresinde
        hedef olarak "PDF olarak kaydet" seçeneğini kullan.
      </p>

      <script>
        window.onload = function () {
          window.print();
        };
      <\/script>
    </body>
    </html>
  `);

  reportWindow.document.close();
  setHistoryMessage(`${items.length} kayıt için PDF raporu hazırlandı.`);
}

function clearHistory() {
  if (!readHistory().length) {
    return setHistoryMessage('Temizlenecek kayıt bulunmuyor.');
  }

  if (!confirm('Tüm hesaplama geçmişi silinsin mi?')) return;

  writeHistory([]);
  renderHistory();
  setHistoryMessage('Hesaplama geçmişi temizlendi.');
}// ========================================
// 17 - ÜÇ FAZ GÜÇ ANALİZİ
// ========================================

function calculateThreePhasePower() {
  const V = getNumber('threePhaseVoltage');
  const I = getNumber('threePhaseCurrent');
  const pf = getNumber('threePhasePF');
  const type = getElement('threePhaseLoad')?.value || 'lagging';

  if ([V, I, pf].some(v => v === null)) {
    return showResult('threePhaseResult', 'Hat gerilimi, hat akımı ve güç faktörünü gir.', true);
  }

  if (V <= 0 || I < 0 || pf < 0 || pf > 1) {
    return showResult('threePhaseResult', 'Gerilim pozitif, akım negatif olmayan ve güç faktörü 0-1 arasında olmalıdır.', true);
  }

  const S = Math.sqrt(3) * V * I;
  const P = S * pf;
  const qMagnitude = S * Math.sqrt(Math.max(0, 1 - pf * pf));
  const Q = type === 'leading' ? -qMagnitude : qMagnitude;
  const phi = Math.acos(pf) * 180 / Math.PI;

  showResult('threePhaseResult', `Hatlar Arası Gerilim: ${formatNumber(V)} V
Hat Akımı: ${formatNumber(I)} A
Yük Karakteri: ${type === 'leading' ? 'Kapasitif (ileri)' : 'Endüktif (geri)'}

Görünür Güç: ${formatNumber(S / 1000)} kVA
Aktif Güç: ${formatNumber(P / 1000)} kW
Reaktif Güç: ${formatNumber(Q / 1000)} kvar
Güç Faktörü: ${formatNumber(pf)}
Faz Açısı: ${formatNumber(phi)}°

Not: Dengeli üç fazlı sistem kabul edilmiştir.`);
}

// ========================================
// 18 - ASENKRON MOTOR HESAPLAMA
// ========================================

function calculateMotor() {
  const Pout = getNumber('motorOutputPower');
  const etaPct = getNumber('motorEfficiency');
  const V = getNumber('motorVoltage');
  const pf = getNumber('motorPF');
  const f = getNumber('motorFrequency');
  const poles = Number(getElement('motorPoles')?.value);
  const n = getNumber('motorSpeed');

  if ([Pout, etaPct, V, pf, f, n].some(v => v === null) ||
      !Number.isFinite(poles)) {
    return showResult('motorResult', 'Tüm motor parametrelerini gir.', true);
  }

  if (Pout <= 0 || etaPct <= 0 || etaPct > 100 ||
      V <= 0 || pf <= 0 || pf > 1 ||
      f <= 0 || n <= 0 || poles <= 0) {
    return showResult('motorResult', 'Güç, gerilim, frekans ve hız pozitif olmalı; verim %0-100, güç faktörü 0-1 aralığında olmalıdır.', true);
  }

  const eta = etaPct / 100;
  const Pin = Pout / eta;
  const I = Pin * 1000 / (Math.sqrt(3) * V * pf);
  const ns = 120 * f / poles;

  if (n >= ns) {
    return showResult('motorResult', `Girilen rotor hızı (${formatNumber(n)} dev/dak), senkron hızdan (${formatNumber(ns)} dev/dak) düşük olmalıdır.`, true);
  }

  const slip = (ns - n) / ns * 100;
  const torque = 9550 * Pout / n;
  const losses = Pin - Pout;
  const S = Math.sqrt(3) * V * I;
  const Q = Math.sqrt(Math.max(0, S * S - (Pin * 1000) ** 2));

  if (![Pin, I, ns, slip, torque, losses, S, Q].every(Number.isFinite)) {
    return showResult('motorResult', 'Sonuç hesaplanamadı; giriş değerlerini kontrol et.', true);
  }

  showResult('motorResult', `MOTOR GİRİŞLERİ
Mil Çıkış Gücü: ${formatNumber(Pout)} kW
Verim: %${formatNumber(etaPct)}
Hat Gerilimi: ${formatNumber(V)} V
Güç Faktörü: ${formatNumber(pf)}
Frekans: ${formatNumber(f)} Hz
Kutup Sayısı: ${poles}

ELEKTRİKSEL SONUÇLAR
Tahmini Giriş Aktif Gücü: ${formatNumber(Pin)} kW
Hat Akımı: ${formatNumber(I)} A
Görünür Güç: ${formatNumber(S / 1000)} kVA
Reaktif Güç: ${formatNumber(Q / 1000)} kvar
Tahmini Kayıp: ${formatNumber(losses)} kW

MEKANİK SONUÇLAR
Senkron Hız: ${formatNumber(ns)} dev/dak
Rotor Hızı: ${formatNumber(n)} dev/dak
Kayma: %${formatNumber(slip)}
Mil Momenti: ${formatNumber(torque)} N·m

Not: Üç fazlı dengeli besleme ve sabit verim kabul edilmiştir.`);
}

function calculateMotorStarting() {
  const ratedCurrent = getNumber('motorRatedCurrent');
  const startingFactor = getNumber('motorStartingFactor');
  const method = getElement('motorStartingMethod')?.value;

  if (ratedCurrent === null || startingFactor === null) {
    return showResult('motorStartingResult', 'Nominal akımı ve kalkış katsayısını gir.', true);
  }

  if (ratedCurrent <= 0 || startingFactor < 1) {
    return showResult('motorStartingResult', 'Nominal akım pozitif, kalkış katsayısı en az 1 olmalıdır.', true);
  }

  const directStartingCurrent = ratedCurrent * startingFactor;
  const selectedStartingCurrent =
    method === 'starDelta'
      ? directStartingCurrent / 3
      : directStartingCurrent;

  showResult('motorStartingResult', `
    <strong>MOTOR KALKIŞ ANALİZİ</strong><br>
    Nominal Akım: ${formatNumber(ratedCurrent)} A<br>
    Direkt Kalkış Akımı: ${formatNumber(directStartingCurrent)} A<br>
    Yıldız-Üçgen Kalkış Akımı: ${formatNumber(directStartingCurrent / 3)} A<br>
    <strong>Seçilen Yöntemin Tahmini Kalkış Akımı: ${formatNumber(selectedStartingCurrent)} A</strong><br><br>
    Akım Azalması: %${formatNumber(method === 'starDelta' ? 66.67 : 0)}<br>
    Not: Yıldız-üçgen hesabı ideal koşullarda yaklaşık 1/3 şebeke kalkış akımı varsayımına dayanır.
  `);
}

function calculateMechanicalMotor() {
  const power = getNumber('mechanicalPower');
  const speed = getNumber('mechanicalSpeed');

  if (power === null || speed === null) {
    return showResult('mechanicalMotorResult', 'Mekanik güç ve motor hızını gir.', true);
  }

  if (power <= 0 || speed <= 0) {
    return showResult('mechanicalMotorResult', 'Mekanik güç ve motor hızı sıfırdan büyük olmalıdır.', true);
  }

  const torque = 9550 * power / speed;
  const hp = power * 1.34102;
  const watt = power * 1000;

  if (![torque, hp, watt].every(Number.isFinite)) {
    return showResult('mechanicalMotorResult', 'Hesaplama yapılamadı. Giriş değerlerini kontrol et.', true);
  }

  showResult('mechanicalMotorResult', `
    <strong>MEKANİK MOTOR SONUÇLARI</strong><br>
    Mekanik Güç: ${formatNumber(power)} kW<br>
    Mekanik Güç: ${formatNumber(watt)} W<br>
    Beygir Gücü: ${formatNumber(hp)} HP<br>
    Motor Hızı: ${formatNumber(speed)} dev/dak<br>
    <strong>Mil Torku: ${formatNumber(torque)} N·m</strong><br><br>
    Formül: T = 9550 × P / n
  `);
}


function calculateSinglePhaseMotor() {
    const power = getNumber('singleMotorPower');
    const voltage = getNumber('singleMotorVoltage');
    const efficiencyPct = getNumber('singleMotorEfficiency');
    const pf = getNumber('singleMotorPF');

    if ([power, voltage, efficiencyPct, pf].some(value => value === null)) {
        showResult('singleMotorResult', 'Tüm motor parametrelerini gir.', true);
        return;
    }

    if (
        power <= 0 ||
        voltage <= 0 ||
        efficiencyPct <= 0 ||
        efficiencyPct > 100 ||
        pf <= 0 ||
        pf > 1
    ) {
        showResult(
            'singleMotorResult',
            'Güç ve gerilim pozitif olmalı; verim %0-100, güç faktörü 0-1 aralığında olmalıdır.',
            true
        );
        return;
    }

    const efficiency = efficiencyPct / 100;
    const inputPower = (power * 1000) / efficiency;
    const current = inputPower / (voltage * pf);
    const apparentPower = voltage * current;
    const reactivePower = Math.sqrt(
        Math.max(0, apparentPower ** 2 - inputPower ** 2)
    );
    const losses = inputPower - power * 1000;

    if (![inputPower, current, apparentPower, reactivePower, losses].every(Number.isFinite)) {
        showResult('singleMotorResult', 'Hesaplama yapılamadı. Değerleri kontrol et.', true);
        return;
    }

    showResult('singleMotorResult', `
        <strong>TEK FAZLI MOTOR SONUÇLARI</strong><br>
        Çıkış Gücü: ${formatNumber(power)} kW<br>
        Giriş Aktif Gücü: ${formatNumber(inputPower / 1000)} kW<br>
        Besleme Gerilimi: ${formatNumber(voltage)} V<br>
        Verim: %${formatNumber(efficiencyPct)}<br>
        Güç Faktörü: ${formatNumber(pf)}<br><br>
        <strong>Motor Akımı: ${formatNumber(current)} A</strong><br>
        Görünür Güç: ${formatNumber(apparentPower / 1000)} kVA<br>
        Reaktif Güç: ${formatNumber(reactivePower / 1000)} kvar<br>
        Tahmini Kayıp: ${formatNumber(losses / 1000)} kW<br><br>
        Not: Sinüzoidal ve kararlı tek fazlı AC besleme varsayılmıştır.
    `);
}
function calculateShortCircuit() {
  const voltage = getNumber('scVoltage');
  const impedance = getNumber('scImpedance');

  if (voltage === null || impedance === null) {
    return showResult(
      'shortCircuitResult',
      'Şebeke gerilimini ve toplam empedansı gir.',
      true
    );
  }

  if (voltage <= 0 || impedance <= 0) {
    return showResult(
      'shortCircuitResult',
      'Gerilim ve empedans sıfırdan büyük olmalıdır.',
      true
    );
  }

  const current = voltage / (Math.sqrt(3) * impedance);

  if (!Number.isFinite(current)) {
    return showResult(
      'shortCircuitResult',
      'Hesaplama yapılamadı. Değerleri kontrol et.',
      true
    );
  }

  showResult('shortCircuitResult', `
    <strong>ÜÇ FAZLI KISA DEVRE SONUÇLARI</strong><br><br>
    Şebeke Gerilimi: ${formatNumber(voltage)} V<br>
    Toplam Empedans: ${formatNumber(impedance)} Ω<br><br>
    <strong>Beklenen Kısa Devre Akımı: ${formatNumber(current)} A</strong><br>
    Kısa Devre Gücü: ${formatNumber(Math.sqrt(3) * voltage * current / 1000)} kVA<br><br>
    Not: Dengeli üç fazlı kısa devre ve fazlar arası 400 V hat gerilimi esas alınmıştır.
  `);
}
function calculateTransformerShortCircuit() {
  const power = getNumber('scTransformerPower');
  const voltage = getNumber('scTransformerVoltage');
  const uk = getNumber('scTransformerUk');

  if ([power, voltage, uk].some(v => v === null)) {
    return showResult(
      'scTransformerResult',
      'Transformatör gücünü, gerilimini ve Uk değerini gir.',
      true
    );
  }

  if (power <= 0 || voltage <= 0 || uk <= 0) {
    return showResult(
      'scTransformerResult',
      'Tüm değerler sıfırdan büyük olmalıdır.',
      true
    );
  }

  const ratedCurrent = (power * 1000) / (Math.sqrt(3) * voltage);
  const shortCircuitCurrent = ratedCurrent * (100 / uk);
  const shortCircuitPower = power * (100 / uk);

  if (![ratedCurrent, shortCircuitCurrent, shortCircuitPower].every(Number.isFinite)) {
    return showResult(
      'scTransformerResult',
      'Hesaplama yapılamadı. Değerleri kontrol et.',
      true
    );
  }

  showResult('scTransformerResult', `
    <strong>TRANSFORMATÖR KISA DEVRE SONUÇLARI</strong><br><br>
    Transformatör Gücü: ${formatNumber(power)} kVA<br>
    Sekonder Gerilimi: ${formatNumber(voltage)} V<br>
    Kısa Devre Gerilimi: %${formatNumber(uk)}<br><br>
    Anma Akımı: ${formatNumber(ratedCurrent)} A<br>
    <strong>Sekonder Kısa Devre Akımı: ${formatNumber(shortCircuitCurrent)} A</strong><br>
    Kısa Devre Gücü: ${formatNumber(shortCircuitPower)} kVA<br><br>
    Not: Şebeke empedansı ve bağlantı kabloları ihmal edilmiştir.
  `);
}
function calculateCableShortCircuit() {
  const voltage = getNumber('scCableVoltage');
  const resistance = getNumber('scCableResistance');
  const reactance = getNumber('scCableReactance');
  const sourceImpedance = getNumber('scCableSourceImpedance');

  if ([voltage, resistance, reactance, sourceImpedance].some(v => v === null)) {
    return showResult(
      'scCableResult',
      'Tüm kısa devre parametrelerini gir.',
      true
    );
  }

  if (
    voltage <= 0 ||
    resistance < 0 ||
    reactance < 0 ||
    sourceImpedance < 0 ||
    (resistance === 0 && reactance === 0 && sourceImpedance === 0)
  ) {
    return showResult(
      'scCableResult',
      'Gerilim pozitif olmalı. Empedans değerleri negatif olamaz ve toplam empedans sıfır olamaz.',
      true
    );
  }

  const totalResistance = resistance + sourceImpedance;
  const totalImpedance = Math.sqrt(
    totalResistance ** 2 + reactance ** 2
  );

  const shortCircuitCurrent = voltage / (Math.sqrt(3) * totalImpedance);
  const shortCircuitPower = Math.sqrt(3) * voltage * shortCircuitCurrent / 1000;

  if (![totalImpedance, shortCircuitCurrent, shortCircuitPower].every(Number.isFinite)) {
    return showResult(
      'scCableResult',
      'Hesaplama yapılamadı. Değerleri kontrol et.',
      true
    );
  }

  showResult('scCableResult', `
    <strong>KABLO EMPEDANSINA GÖRE KISA DEVRE SONUÇLARI</strong><br><br>
    Şebeke Gerilimi: ${formatNumber(voltage)} V<br>
    Kablo Direnci: ${formatNumber(resistance)} Ω/faz<br>
    Kablo Reaktansı: ${formatNumber(reactance)} Ω/faz<br>
    Kaynak Empedansı: ${formatNumber(sourceImpedance)} Ω/faz<br><br>
    Toplam Empedans: ${formatNumber(totalImpedance)} Ω/faz<br>
    <strong>Kısa Devre Akımı: ${formatNumber(shortCircuitCurrent)} A</strong><br>
    Kısa Devre Gücü: ${formatNumber(shortCircuitPower)} kVA<br><br>
    Not: Dengeli üç fazlı kısa devre ve faz başına eşdeğer empedans varsayılmıştır.
  `);
}
function calculateBreakerCheck() {
  const loadCurrent = getNumber('breakerLoadCurrent');
  const cableCapacity = getNumber('breakerCableCapacity');
  const ratedCurrent = getNumber('breakerRatedCurrent');
  const shortCircuitCurrent = getNumber('breakerShortCircuitCurrent');
  const breakingCapacity = getNumber('breakerBreakingCapacity');

  const values = [
    loadCurrent,
    cableCapacity,
    ratedCurrent,
    shortCircuitCurrent,
    breakingCapacity
  ];

  if (values.some(v => v === null)) {
    return showResult(
      'breakerCheckResult',
      'Lütfen tüm koruma elemanı parametrelerini gir.',
      true
    );
  }

  if (values.some(v => v <= 0)) {
    return showResult(
      'breakerCheckResult',
      'Tüm değerler sıfırdan büyük olmalıdır.',
      true
    );
  }

  const condition1 = loadCurrent <= ratedCurrent;
  const condition2 = ratedCurrent <= cableCapacity;
  const condition3 = breakingCapacity * 1000 >= shortCircuitCurrent;

  const allSuitable = condition1 && condition2 && condition3;

  showResult('breakerCheckResult', `
    <strong>KORUMA ELEMANI UYGUNLUK ANALİZİ</strong><br><br>

    Tasarım Yük Akımı (Ib): ${formatNumber(loadCurrent)} A<br>
    Kablo Akım Kapasitesi (Iz): ${formatNumber(cableCapacity)} A<br>
    Kesici Anma Akımı (In): ${formatNumber(ratedCurrent)} A<br>
    Beklenen Kısa Devre Akımı (Ik): ${formatNumber(shortCircuitCurrent)} A<br>
    Kesici Kesme Kapasitesi (Icu): ${formatNumber(breakingCapacity)} kA<br><br>

    <strong>KOŞUL KONTROLLERİ</strong><br><br>

    Ib ≤ In:
    <strong>${condition1 ? 'UYGUN' : 'UYGUN DEĞİL'}</strong><br>

    In ≤ Iz:
    <strong>${condition2 ? 'UYGUN' : 'UYGUN DEĞİL'}</strong><br>

    Icu ≥ Ik:
    <strong>${condition3 ? 'UYGUN' : 'UYGUN DEĞİL'}</strong><br><br>

    <strong>GENEL SONUÇ: ${allSuitable ? 'TEMEL KOŞULLAR SAĞLANIYOR' : 'UYGUNLUK SAĞLANMIYOR'}</strong><br><br>

    Not: Bu sonuç ön değerlendirmedir. Koruma koordinasyonu ve ilgili standart kontrolleri ayrıca yapılmalıdır.
  `);
}

function calculateGeneratorPower() {
  const activePower = getNumber('generatorActivePower');
  const powerFactor = getNumber('generatorPowerFactor');

  if (activePower === null || powerFactor === null) {
    return showResult(
      'generatorPowerResult',
      'Lütfen aktif güç ve güç faktörü değerlerini gir.',
      true
    );
  }

  if (activePower <= 0 || powerFactor <= 0 || powerFactor > 1) {
    return showResult(
      'generatorPowerResult',
      'Aktif güç sıfırdan büyük, güç faktörü ise 0 ile 1 arasında olmalıdır.',
      true
    );
  }

  const apparentPower = activePower / powerFactor;
  const reactivePower = Math.sqrt(
    apparentPower ** 2 - activePower ** 2
  );

  showResult('generatorPowerResult', `
    <strong>JENERATÖR GÜÇ ANALİZİ</strong><br><br>

    Aktif Güç (P): ${formatNumber(activePower)} kW<br>
    Güç Faktörü (cosφ): ${formatNumber(powerFactor)}<br>
    Görünür Güç (S): ${formatNumber(apparentPower)} kVA<br>
    Reaktif Güç (Q): ${formatNumber(reactivePower)} kVAr<br><br>

    <strong>Gerekli Jeneratör Gücü: ${formatNumber(apparentPower)} kVA</strong><br><br>

    Not: Hesaplama ideal güç faktörü ve sürekli çalışma koşulları üzerinden yapılır. Gerçek jeneratör seçiminde yük karakteristiği, kalkış akımları ve yedek kapasite de değerlendirilmelidir.
  `);
}

function calculateGeneratorCurrent() {
  const ratedPower = getNumber('generatorRatedPower');
  const voltage = getNumber('generatorVoltage');
  const phase = getElement('generatorPhase').value;

  if (ratedPower === null || voltage === null) {
    return showResult(
      'generatorCurrentResult',
      'Lütfen jeneratör gücü ve gerilim değerlerini gir.',
      true
    );
  }

  if (ratedPower <= 0 || voltage <= 0) {
    return showResult(
      'generatorCurrentResult',
      'Güç ve gerilim değerleri sıfırdan büyük olmalıdır.',
      true
    );
  }

  const current = phase === '3'
    ? (ratedPower * 1000) / (Math.sqrt(3) * voltage)
    : (ratedPower * 1000) / voltage;

  showResult('generatorCurrentResult', `
    <strong>JENERATÖR ANMA AKIMI ANALİZİ</strong><br><br>

    Jeneratör Anma Gücü: ${formatNumber(ratedPower)} kVA<br>
    Çıkış Gerilimi: ${formatNumber(voltage)} V<br>
    Faz Sayısı: ${phase === '3' ? 'Üç Fazlı' : 'Tek Fazlı'}<br><br>

    <strong>Anma Akımı: ${formatNumber(current)} A</strong><br><br>

    Not: Hesaplama dengeli üç fazlı sistem veya tek fazlı sistem varsayımıyla yapılmıştır.
  `);
}

function calculateGeneratorLoad() {
  const ratedPower = getNumber('generatorLoadRated');
  const loadPower = getNumber('generatorLoadPower');
  const powerFactor = getNumber('generatorLoadFactor');

  if (
    ratedPower === null ||
    loadPower === null ||
    powerFactor === null
  ) {
    return showResult(
      'generatorLoadResult',
      'Lütfen tüm yüklenme analizi değerlerini gir.',
      true
    );
  }

  if (
    ratedPower <= 0 ||
    loadPower <= 0 ||
    powerFactor <= 0 ||
    powerFactor > 1
  ) {
    return showResult(
      'generatorLoadResult',
      'Güç değerleri sıfırdan büyük, güç faktörü ise 0 ile 1 arasında olmalıdır.',
      true
    );
  }

  const apparentLoad = loadPower / powerFactor;
  const loadPercentage = (apparentLoad / ratedPower) * 100;
  const remainingCapacity = ratedPower - apparentLoad;

  let status = '';

  if (loadPercentage < 70) {
    status = 'DÜŞÜK YÜKLENME';
  } else if (loadPercentage <= 90) {
    status = 'UYGUN YÜKLENME';
  } else if (loadPercentage <= 100) {
    status = 'YÜKSEK YÜKLENME';
  } else {
    status = 'AŞIRI YÜKLENME';
  }

  showResult('generatorLoadResult', `
    <strong>JENERATÖR YÜKLENME ANALİZİ</strong><br><br>

    Jeneratör Anma Gücü: ${formatNumber(ratedPower)} kVA<br>
    Bağlı Yük Aktif Gücü: ${formatNumber(loadPower)} kW<br>
    Yük Güç Faktörü: ${formatNumber(powerFactor)}<br>
    Görünür Yük Gücü: ${formatNumber(apparentLoad)} kVA<br><br>

    <strong>Yüklenme Oranı: %${formatNumber(loadPercentage)}</strong><br>
    Kalan Kapasite: ${formatNumber(remainingCapacity)} kVA<br><br>

    <strong>Durum: ${status}</strong><br><br>

    Not: Yüklenme sınıfları genel ön değerlendirme amaçlıdır. Üretici çalışma sınırları ve yük karakteristiği ayrıca incelenmelidir.
  `);
}

function calculateGeneratorEfficiency() {
  const inputPower = getNumber('generatorInputPower');
  const outputPower = getNumber('generatorOutputPower');

  if (inputPower === null || outputPower === null) {
    return showResult(
      'generatorEfficiencyResult',
      'Lütfen mekanik giriş ve elektriksel çıkış gücünü gir.',
      true
    );
  }

  if (inputPower <= 0 || outputPower <= 0) {
    return showResult(
      'generatorEfficiencyResult',
      'Güç değerleri sıfırdan büyük olmalıdır.',
      true
    );
  }

  if (outputPower > inputPower) {
    return showResult(
      'generatorEfficiencyResult',
      'Elektriksel çıkış gücü mekanik giriş gücünden büyük olamaz.',
      true
    );
  }

  const efficiency = (outputPower / inputPower) * 100;
  const losses = inputPower - outputPower;

  showResult('generatorEfficiencyResult', `
    <strong>JENERATÖR VERİM ANALİZİ</strong><br><br>

    Mekanik Giriş Gücü: ${formatNumber(inputPower)} kW<br>
    Elektriksel Çıkış Gücü: ${formatNumber(outputPower)} kW<br>
    Toplam Güç Kaybı: ${formatNumber(losses)} kW<br><br>

    <strong>Jeneratör Verimi: %${formatNumber(efficiency)}</strong><br><br>

    Not: Bu hesaplama mekanik giriş gücünden elektriksel çıkış gücüne dönüşüm verimini gösterir.
  `);
}

function calculateEarthRodResistance() {
  const resistivity = getNumber('earthResistivity');
  const length = getNumber('earthRodLength');
  const diameter = getNumber('earthRodDiameter');

  if (resistivity === null || length === null || diameter === null) {
    return showResult(
      'earthRodResult',
      'Lütfen tüm elektrot parametrelerini gir.',
      true
    );
  }

  if (resistivity <= 0 || length <= 0 || diameter <= 0) {
    return showResult(
      'earthRodResult',
      'Tüm değerler sıfırdan büyük olmalıdır.',
      true
    );
  }

  if (diameter >= length) {
    return showResult(
      'earthRodResult',
      'Elektrot çapı uzunluğundan küçük olmalıdır.',
      true
    );
  }

  const resistance =
    (resistivity / (2 * Math.PI * length)) *
    (Math.log((4 * length) / diameter) - 1);

  showResult('earthRodResult', `
    <strong>DÜŞEY TOPRAKLAMA ELEKTRODU ANALİZİ</strong><br><br>

    Toprak Özdirenci: ${formatNumber(resistivity)} Ω·m<br>
    Elektrot Uzunluğu: ${formatNumber(length)} m<br>
    Elektrot Çapı: ${formatNumber(diameter)} m<br><br>

    <strong>Hesaplanan Topraklama Direnci: ${formatNumber(resistance)} Ω</strong><br><br>

    Not: Bu sonuç tek düşey elektrot için yaklaşık teorik hesaplamadır. Gerçek direnç; toprak tabakaları, nem, sıcaklık, elektrot geometrisi ve diğer elektrotların etkileşiminden etkilenir. Uygunluk ölçümle doğrulanmalıdır.
  `);
}

function calculateEarthConductor() {
  const faultCurrent = getNumber('earthFaultCurrent');
  const faultTime = getNumber('earthFaultTime');
  const k = getNumber('earthConductorK');

  if (faultCurrent === null || faultTime === null || k === null) {
    return showResult(
      'earthConductorResult',
      'Lütfen tüm koruma iletkeni parametrelerini gir.',
      true
    );
  }

  if (faultCurrent <= 0 || faultTime <= 0 || k <= 0) {
    return showResult(
      'earthConductorResult',
      'Tüm değerler sıfırdan büyük olmalıdır.',
      true
    );
  }

  const requiredSection = (faultCurrent * Math.sqrt(faultTime)) / k;

  showResult('earthConductorResult', `
    <strong>KORUMA İLETKENİ KESİT ANALİZİ</strong><br><br>

    Arıza Akımı: ${formatNumber(faultCurrent)} A<br>
    Açma Süresi: ${formatNumber(faultTime)} s<br>
    Malzeme Katsayısı (k): ${formatNumber(k)}<br><br>

    <strong>Hesaplanan Minimum Kesit: ${formatNumber(requiredSection)} mm²</strong><br><br>

    Not: Adyabatik yöntemle hesaplanmıştır. Kullanılan k katsayısı iletken malzemesine, yalıtım türüne ve başlangıç/son sıcaklıklarına uygun seçilmelidir. Standartların öngördüğü minimum kesitler ve mekanik dayanım ayrıca kontrol edilmelidir.
  `);
}

function calculateRCDCheck() {
  const earthResistance = getNumber('rcdEarthResistance');
  const ratedCurrentmA = getNumber('rcdRatedCurrent');
  const touchVoltage = getNumber('rcdTouchVoltage');

  if (
    earthResistance === null ||
    ratedCurrentmA === null ||
    touchVoltage === null
  ) {
    return showResult(
      'rcdCheckResult',
      'Lütfen tüm kaçak akım koruma parametrelerini gir.',
      true
    );
  }

  if (
    earthResistance <= 0 ||
    ratedCurrentmA <= 0 ||
    touchVoltage <= 0
  ) {
    return showResult(
      'rcdCheckResult',
      'Tüm değerler sıfırdan büyük olmalıdır.',
      true
    );
  }

  const ratedCurrentA = ratedCurrentmA / 1000;
  const calculatedTouchVoltage = earthResistance * ratedCurrentA;
  const isSuitable = calculatedTouchVoltage <= touchVoltage;

  showResult('rcdCheckResult', `
    <strong>KAÇAK AKIM KORUMA ANALİZİ</strong><br><br>

    Topraklama Direnci (RA): ${formatNumber(earthResistance)} Ω<br>
    Kaçak Akım Açma Değeri (IΔn): ${formatNumber(ratedCurrentmA)} mA<br>
    İzin Verilen Dokunma Gerilimi (UL): ${formatNumber(touchVoltage)} V<br><br>

    Hesaplanan Gerilim (RA × IΔn):
    ${formatNumber(calculatedTouchVoltage)} V<br><br>

    <strong>SONUÇ: ${isSuitable ? 'TEMEL KOŞUL SAĞLANIYOR' : 'TEMEL KOŞUL SAĞLANMIYOR'}</strong><br><br>

    Not: Bu kontrol TT sistemleri için kullanılan dokunma gerilimi koşulunun ön değerlendirmesidir. RCD tipi, açma süresi, seçicilik, tesisatın diğer koruma koşulları ve ölçüm sonuçları ayrıca doğrulanmalıdır.
  `);
}

function calculateEarthingSystem() {
  const system = getElement('earthingSystem').value;
  const impedance = getNumber('systemEarthResistance');
  const tripCurrent = getNumber('systemFaultCurrent');
  const touchVoltage = getNumber('systemTouchVoltage');
  const phaseVoltage = getNumber('systemVoltage');
  const disconnectionTime = getNumber('systemDisconnectionTime');

  if (
    impedance === null ||
    tripCurrent === null ||
    touchVoltage === null ||
    phaseVoltage === null ||
    disconnectionTime === null
  ) {
    return showResult(
      'earthingSystemResult',
      'Lütfen tüm topraklama sistemi parametrelerini gir.',
      true
    );
  }

  if (
    impedance <= 0 ||
    tripCurrent <= 0 ||
    touchVoltage <= 0 ||
    phaseVoltage <= 0 ||
    disconnectionTime <= 0
  ) {
    return showResult(
      'earthingSystemResult',
      'Tüm değerler sıfırdan büyük olmalıdır.',
      true
    );
  }

  let condition;
  let calculatedValue;
  let formula;
  let explanation;

  if (system === 'TT') {
    calculatedValue = impedance * tripCurrent;
    condition = calculatedValue <= touchVoltage;
    formula = 'RA × Ia ≤ UL';
    explanation = `
      Topraklama direnci × koruma elemanı açma akımı:
      ${formatNumber(calculatedValue)} V<br>
      İzin verilen dokunma gerilimi:
      ${formatNumber(touchVoltage)} V
    `;
  } else {
    calculatedValue = impedance * tripCurrent;
    condition = calculatedValue <= phaseVoltage;
    formula = 'Zs × Ia ≤ U0';
    explanation = `
      Hata döngüsü empedansı × açma akımı:
      ${formatNumber(calculatedValue)} V<br>
      Faz-toprak gerilimi:
      ${formatNumber(phaseVoltage)} V
    `;
  }

  showResult('earthingSystemResult', `
    <strong>${system} TOPRAKLAMA SİSTEMİ ANALİZİ</strong><br><br>

    Sistem Türü: ${system}<br>
    ${system === 'TT' ? 'Topraklama Direnci (RA)' : 'Hata Döngüsü Empedansı (Zs)'}:
    ${formatNumber(impedance)} Ω<br>
    Koruma Elemanı Açma Akımı (Ia):
    ${formatNumber(tripCurrent)} A<br>
    Açma Süresi:
    ${formatNumber(disconnectionTime)} s<br><br>

    <strong>Kontrol Koşulu: ${formula}</strong><br><br>

    ${explanation}<br><br>

    <strong>Temel Koşul: ${condition ? 'SAĞLANIYOR' : 'SAĞLANMIYOR'}</strong><br><br>

    Not: Bu hesaplama yalnızca temel empedans-akım koşulunu kontrol eder. Açma süresi, koruma elemanı karakteristiği, RCD kullanımı, iletken sürekliliği ve ilgili standart şartları ayrıca doğrulanmalıdır.
  `);
}


// ========================================
// 19 - UYGULAMA BAŞLATMA VE OLAYLAR
// ========================================

function initializeApp() {
  console.log("initializeApp çalıştı.");
    const activePage = document.querySelector('.page.active');

  if (activePage) {
    const activeButton = document.querySelector(
      `.nav-btn[data-page="${activePage.id}"]`
    );

    const activeGroup = activeButton?.closest('.menu-group');

    document.querySelectorAll('.menu-group').forEach(group => {
      group.open = group === activeGroup;
    });
  }
    document.querySelectorAll('.nav-btn').forEach(button => {
  button.addEventListener('click', () => {
    showPage(button.dataset.page);

    const selectedGroup = button.closest('.menu-group');

    document.querySelectorAll('.menu-group').forEach(group => {
      group.open = group === selectedGroup;
    });
  });
});

  document.querySelectorAll('.card').forEach(card => {
    card.addEventListener('click', () => {
      const targetPage = card.dataset.page || card.dataset.target;

      if (targetPage) {
        showPage(targetPage);
      }
    });
  });

  const actions = {
    ohmButton: calculateOhm,
    powerButton: calculateDCPower,
    resistanceButton: calculateResistance,
    convertButton: convertUnit,
    acPowerButton: calculateACPower,
    compensationButton: calculateCompensation,
    harmonicAnalysisButton: calculateHarmonicAnalysis,
    harmonicFilterButton: calculateHarmonicFilter,
    ieee519Button: calculateIEEE519,
    capacitorReactanceButton: calculateCapacitorReactance,
    capacitorChargeButton: calculateCapacitorCharge,
    inductorButton: calculateInductor,
    impedanceButton: calculateImpedance,
    resonanceButton: calculateResonance,

    transformerButton: calculateTransformer,
    ocButton: calculateOpenCircuit,

    
    performanceButton: calculateTransformerPerformance,

    cableSizingButton: calculateCableSizing,
    cableCapacityButton: calculateCableCapacity,
    voltageDropButton: calculateVoltageDrop,

    threePhaseButton: calculateThreePhasePower,
    motorButton: calculateMotor,
    motorStartingButton: calculateMotorStarting,
    mechanicalMotorButton: calculateMechanicalMotor,
    singleMotorButton: calculateSinglePhaseMotor,

    shortCircuitButton: calculateShortCircuit,
    scTransformerButton: calculateTransformerShortCircuit,
    scCableButton: calculateCableShortCircuit,
    breakerCheckButton: calculateBreakerCheck,

    generatorPowerButton: calculateGeneratorPower,
    generatorCurrentButton: calculateGeneratorCurrent,
    generatorLoadButton: calculateGeneratorLoad,
    generatorEfficiencyButton: calculateGeneratorEfficiency,

    earthRodButton: calculateEarthRodResistance,
    earthConductorButton: calculateEarthConductor,
    rcdCheckButton: calculateRCDCheck,
    earthingSystemButton: calculateEarthingSystem,

    swapUnitsButton: swapUnits
};

  Object.entries(actions).forEach(([id, fn]) => {
    const button = getElement(id);
    if (button) button.addEventListener('click', fn);
    console.log("IEEE buton:", getElement("ieee519Button"));
console.log("IEEE fonksiyon:", typeof calculateIEEE519);
  });
  let ohmChartInstance = null;

const generateOhmChartButton = getElement('generateOhmChart');

if (generateOhmChartButton) {
  generateOhmChartButton.addEventListener('click', function () {
    const resistance = getNumber('chartResistance');
    const maxVoltage = getNumber('chartMaxVoltage');

    if (resistance === null || maxVoltage === null) {
      alert('Lütfen direnç ve maksimum gerilim değerlerini gir.');
      return;
    }

    if (resistance <= 0 || maxVoltage <= 0) {
      alert('Değerler sıfırdan büyük olmalıdır.');
      return;
    }

    if (typeof Chart === 'undefined') {
      alert('Grafik kütüphanesi yüklenemedi. İnternet bağlantını kontrol et.');
      return;
    }

    const labels = [];
    const currentValues = [];

    for (let i = 0; i <= 10; i++) {
      const voltage = (maxVoltage / 10) * i;
      labels.push(Number(voltage.toFixed(2)));
      currentValues.push(Number((voltage / resistance).toFixed(4)));
    }

    const canvas = getElement('ohmChart');

    if (ohmChartInstance) {
      ohmChartInstance.destroy();
    }

    ohmChartInstance = new Chart(canvas, {
      type: 'line',
      data: {
        labels: labels,
        datasets: [{
          label: 'Akım (A)',
          data: currentValues,
          borderWidth: 2,
          tension: 0.2,
          fill: false
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
          x: {
            title: {
              display: true,
              text: 'Gerilim (V)'
            }
          },
          y: {
            beginAtZero: true,
            title: {
              display: true,
              text: 'Akım (A)'
            }
          }
        }
      }
    });
  });
}
let powerChartInstance = null;

const generatePowerChartButton = getElement('generatePowerChart');

if (generatePowerChartButton) {
  generatePowerChartButton.addEventListener('click', function () {
    const resistance = getNumber('chartPowerResistance');
    const maxVoltage = getNumber('chartPowerMaxVoltage');

    if (resistance === null || maxVoltage === null) {
      alert('Lütfen tüm değerleri gir.');
      return;
    }

    if (resistance <= 0 || maxVoltage <= 0) {
      alert('Değerler sıfırdan büyük olmalıdır.');
      return;
    }

    if (typeof Chart === 'undefined') {
      alert('Grafik kütüphanesi yüklenemedi.');
      return;
    }

    const labels = [];
    const powerValues = [];

    for (let i = 0; i <= 10; i++) {
      const voltage = (maxVoltage / 10) * i;
      const power = (voltage * voltage) / resistance;

      labels.push(Number(voltage.toFixed(2)));
      powerValues.push(Number(power.toFixed(2)));
    }

    const canvas = getElement('powerChart');

    if (powerChartInstance) {
      powerChartInstance.destroy();
    }

    powerChartInstance = new Chart(canvas, {
      type: 'line',
      data: {
        labels: labels,
        datasets: [{
          label: 'Güç (W)',
          data: powerValues,
          borderWidth: 2,
          tension: 0.2,
          fill: false
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
          x: {
            title: {
              display: true,
              text: 'Gerilim (V)'
            }
          },
          y: {
            beginAtZero: true,
            title: {
              display: true,
              text: 'Güç (W)'
            }
          }
        }
      }
    });
  });
}

  getElement('convertCategory')?.addEventListener('change', populateUnitOptions);

  getElement('historyList')?.addEventListener('click', handleHistoryAction);
  getElement('exportHistoryButton')?.addEventListener('click', exportHistoryCSV);
  getElement('exportHistoryPDFButton')?.addEventListener('click', exportHistoryPDF);
  getElement('clearHistoryButton')?.addEventListener('click', clearHistory);

  const mappings = {
    voltage: calculateOhm,
    current: calculateOhm,
    resistanceOhm: calculateOhm,
    powerVoltage: calculateDCPower,
    powerCurrent: calculateDCPower,
    resistorValues: calculateResistance,
    convertValue: convertUnit,
    acVoltage: calculateACPower,
    acCurrent: calculateACPower,
    powerFactor: calculateACPower,
    compensationPower: calculateCompensation,
    compensationCurrentPF: calculateCompensation,
    compensationTargetPF: calculateCompensation,
    compensationVoltage: calculateCompensation,
    compensationFrequency: calculateCompensation,
    capacitorFrequency: calculateCapacitorReactance,
    capacitorValue: calculateCapacitorReactance,
    chargeCapacitance: calculateCapacitorCharge,
    chargeVoltage: calculateCapacitorCharge,
    inductorFrequency: calculateInductor,
    inductorValue: calculateInductor,
    impedanceResistance: calculateImpedance,
    impedanceInductance: calculateImpedance,
    impedanceCapacitance: calculateImpedance,
    impedanceFrequency: calculateImpedance,
    resonanceInductance: calculateResonance,
    resonanceCapacitance: calculateResonance,
    primaryVoltage: calculateTransformer,
    secondaryVoltage: calculateTransformer,
    primaryTurns: calculateTransformer,
    secondaryTurns: calculateTransformer,
    primaryCurrent: calculateTransformer,
    transformerEfficiency: calculateTransformer,
    ocVoltage: calculateOpenCircuit,
    ocCurrent: calculateOpenCircuit,
    ocPower: calculateOpenCircuit,
    scButton: calculateTransformerShortCircuitTest,
scTransformerButton: calculateTransformerShortCircuit,
    ratedPower: calculateTransformerPerformance,
    ratedSecondaryVoltage: calculateTransformerPerformance,
    loadPercentage: calculateTransformerPerformance,
    loadPowerFactor: calculateTransformerPerformance,
    cableSizingCurrent: calculateCableSizing,
    cableCurrentDensity: calculateCableSizing,
    cableCapacityDensity: calculateCableCapacity,
    cableTemperatureFactor: calculateCableCapacity,
    cableGroupingFactor: calculateCableCapacity,
    cableInstallationFactor: calculateCableCapacity,
    voltageDropVoltage: calculateVoltageDrop,
    voltageDropCurrent: calculateVoltageDrop,
    voltageDropLength: calculateVoltageDrop,
    voltageDropPF: calculateVoltageDrop,
    voltageDropReactance: calculateVoltageDrop,
    threePhaseVoltage: calculateThreePhasePower,
    threePhaseCurrent: calculateThreePhasePower,
    threePhasePF: calculateThreePhasePower,
    motorOutputPower: calculateMotor,
    motorEfficiency: calculateMotor,
    motorVoltage: calculateMotor,
    motorPF: calculateMotor,
    motorFrequency: calculateMotor,
    motorSpeed: calculateMotor
  };

  Object.entries(mappings).forEach(([id, fn]) => {
    const element = getElement(id);

    if (element) {
      element.addEventListener('keydown', event => {
        if (event.key === 'Enter') {
          event.preventDefault();
          fn();
        }
      });
    }
  });

  populateUnitOptions();
  renderHistory();
}

function calculateIEEE519() {
    const pccVoltage = Number(getElement('ieeePccVoltageKv')?.value);
    const iscKA = Number(getElement('ieeeIscKA')?.value);
    const il = Number(getElement('ieeeIL')?.value);

    const fundamentalCurrent = Number(
        getElement('harmonicFundamentalCurrent')?.value
    );

    const fundamentalVoltage = Number(
        getElement('harmonicFundamentalVoltage')?.value
    );

    if (
        !Number.isFinite(pccVoltage) ||
        !Number.isFinite(iscKA) ||
        !Number.isFinite(il) ||
        pccVoltage < 0.12 ||
        iscKA <= 0 ||
        il <= 0 ||
        fundamentalCurrent <= 0 ||
        fundamentalVoltage <= 0
    ) {
        showResult(
            'ieee519Result',
            'PCC gerilimi, Isc, IL ve temel akım-gerilim değerlerini kontrol ediniz.',
            true
        );
        return;
    }

    const orders = [3, 5, 7, 11, 13];

    const currentHarmonics = orders.map(order =>
        Number(getElement(`harmonic${order}`)?.value ?? 0)
    );

    const voltageHarmonics = orders.map(order =>
        Number(getElement(`harmonicVoltage${order}`)?.value ?? 0)
    );

    if (
        currentHarmonics.some(value => !Number.isFinite(value) || value < 0) ||
        voltageHarmonics.some(value => !Number.isFinite(value) || value < 0)
    ) {
        showResult(
            'ieee519Result',
            'Harmonik değerleri negatif veya geçersiz olamaz.',
            true
        );
        return;
    }

    // IEEE 519-2022 gerilim sınırları
    let individualVoltageLimit;
    let totalVoltageLimit;
    let voltageClass;

    if (pccVoltage <= 1) {
        individualVoltageLimit = 5;
        totalVoltageLimit = 8;
        voltageClass = '120 V – 1 kV';
    } else if (pccVoltage <= 69) {
        individualVoltageLimit = 3;
        totalVoltageLimit = 5;
        voltageClass = '1 kV – 69 kV';
    } else if (pccVoltage <= 161) {
        individualVoltageLimit = 1.5;
        totalVoltageLimit = 2.5;
        voltageClass = '69 kV – 161 kV';
    } else {
        individualVoltageLimit = 1;
        totalVoltageLimit = 1.5;
        voltageClass = '161 kV üzeri';
    }

    // Gerilim harmonik yüzdeleri ve kısmi THDv
    const voltagePercentages = voltageHarmonics.map(value =>
        value / fundamentalVoltage * 100
    );

    const thdv = Math.sqrt(
        voltageHarmonics.reduce((sum, value) => sum + value ** 2, 0)
    ) / fundamentalVoltage * 100;

    const voltageRows = orders.map((order, index) => {
        const percentage = voltagePercentages[index];
        const passed = percentage <= individualVoltageLimit;

        return `
            <tr>
                <td>${order}.</td>
                <td>%${percentage.toFixed(2)}</td>
                <td>%${individualVoltageLimit.toFixed(2)}</td>
                <td>${passed ? 'Uygun' : 'Sınır aşıldı'}</td>
            </tr>
        `;
    }).join('');

    const voltageTHDPassed = thdv <= totalVoltageLimit;

    // Kısa devre / maksimum talep akımı oranı
    const isc = iscKA * 1000;
    const ratio = isc / il;

    // IEEE 519-2022 Tablo 2: 120 V - 69 kV
   const currentLimits = [
    { max: 20, limits: [4, 2, 1.5, 0.6, 0.3], tdd: 5 },
    { max: 50, limits: [7, 3.5, 2.5, 1, 0.5], tdd: 8 },
    { max: 100, limits: [10, 4.5, 4, 1.5, 0.7], tdd: 12 },
    { max: 1000, limits: [12, 5.5, 5, 2, 1], tdd: 15 },
    { max: Infinity, limits: [15, 7, 6, 2.5, 1.4], tdd: 20 }
];

const selectedLimit = currentLimits.find(row => ratio < row.max);

if (!selectedLimit) {
    showResult('ieee519Result', 'Akım sınırı tablosu seçilemedi.', true);
    return;
}

const getCurrentHarmonicLimit = (order) => {
    if (order < 11) return selectedLimit.limits[0];
    if (order < 17) return selectedLimit.limits[1];
    if (order < 23) return selectedLimit.limits[2];
    if (order < 35) return selectedLimit.limits[3];
    return selectedLimit.limits[4];
};
    // Kısmi TDD hesabı
    const partialTDD = Math.sqrt(
        currentHarmonics.reduce((sum, value) => sum + value ** 2, 0)
    ) / il * 100;
const currentRows = orders.map((order, index) => {
    const percentage = currentHarmonics[index] / il * 100;
    const limit = getCurrentHarmonicLimit(order);

    return `
        <tr>
            <td>${order}.</td>
            <td>%${percentage.toFixed(2)}</td>
            <td>%${limit.toFixed(2)}</td>
            <td>${percentage <= limit ? 'Uygun' : 'Sınır aşıldı'}</td>
        </tr>
    `;
}).join('');

const currentApplicable = pccVoltage <= 69;
const tddPassed = partialTDD <= selectedLimit.tdd;
    const voltageStatus = voltageTHDPassed &&
        voltagePercentages.every(value => value <= individualVoltageLimit);

    const currentStatus = orders.every((order, index) => {
    const limit = getCurrentHarmonicLimit(order);

    return currentHarmonics[index] / il * 100 <= limit;
}) && tddPassed;

    const result = `
        <h3>IEEE 519-2022 Değerlendirme Sonucu</h3>

        <h4>1. Sistem Bilgileri</h4>
        <p>PCC gerilimi: <strong>${pccVoltage.toFixed(3)} kV</strong></p>
        <p>Gerilim sınıfı: <strong>${voltageClass}</strong></p>
        <p>Kısa devre akımı Isc: <strong>${iscKA.toFixed(3)} kA</strong></p>
        <p>Maksimum talep akımı IL: <strong>${il.toFixed(2)} A</strong></p>
        <p>Isc / IL oranı: <strong>${ratio.toFixed(2)}</strong></p>

        <hr>

        <h4>2. Gerilim Harmonik Kontrolü</h4>
        <p>Hesaplanan THDv: <strong>%${thdv.toFixed(2)}</strong></p>
        <p>İzin verilen THDv: <strong>%${totalVoltageLimit.toFixed(2)}</strong></p>
        <p>THDv değerlendirmesi:
            <strong>${voltageTHDPassed ? 'Uygun' : 'Sınır aşıldı'}</strong>
        </p>

        <div style="overflow-x:auto;">
            <table>
                <thead>
                    <tr>
                        <th>Harmonik</th>
                        <th>Ölçülen</th>
                        <th>Sınır</th>
                        <th>Durum</th>
                    </tr>
                </thead>
                <tbody>${voltageRows}</tbody>
            </table>
        </div>

        <hr>

        <h4>3. Akım Harmonik Kontrolü</h4>
        ${
            currentApplicable
            ? `
                <p>Seçilen Isc/IL sınır grubu:
                    <strong>Harmonik derecesine göre değişken sınırlar</strong>
                </p>
                <p>Kısmi TDD: <strong>%${partialTDD.toFixed(2)}</strong></p>
                <p>IEEE TDD sınırı: <strong>%${selectedLimit.tdd.toFixed(2)}</strong></p>
                <p>Kısmi TDD kontrolü:
                    <strong>${tddPassed ? 'Sınır içinde' : 'Sınır aşıldı'}</strong>
                </p>

                <div style="overflow-x:auto;">
                    <table>
                        <thead>
                            <tr>
                                <th>Harmonik</th>
                                <th>Akım / IL</th>
                                <th>İzin verilen</th>
                                <th>Durum</th>
                            </tr>
                        </thead>
                        <tbody>${currentRows}</tbody>
                    </table>
                </div>
            `
            : `
                <p>Bu sürümün akım sınırları yalnızca 120 V – 69 kV aralığında uygulanır. Bu PCC gerilimi için akım değerlendirmesi henüz desteklenmiyor.</p>
            `
        }

        <hr>

        <h4>4. Genel Ön Değerlendirme</h4>
        <p>Gerilim kontrolü:
            <strong>${voltageStatus ? 'Girilen değerler sınırlar içinde' : 'En az bir sınır aşılmış'}</strong>
        </p>
        <p>Akım kontrolü:
            <strong>${
                !currentApplicable
                    ? 'Değerlendirme kapsam dışı'
                    : currentStatus
                        ? 'Girilen değerler sınırlar içinde'
                        : 'En az bir sınır aşılmış'
            }</strong>
        </p>

        <small>
            Önemli: Bu sonuç yalnızca girilen 3., 5., 7., 11. ve 13. harmoniklere
            dayalı ön değerlendirmedir. Kısmi TDD, tam TDD değildir.
            IEEE 519 uygunluğu için 50. harmoniğe kadar gerekli ölçümler,
            PCC doğrulaması ve standarttaki zaman yüzdelikleri incelenmelidir.
            Bireysel yüklerin tek başına değerlendirilmesi için bu sınırlar
            kullanılmamalıdır.
        </small>
    `;

    showResult('ieee519Result', result);
}

function createElectricalChart(canvasId, oldChart, labels, values, label, xTitle, yTitle) {
  const canvas = getElement(canvasId);
  if (!canvas || typeof Chart === 'undefined') return oldChart;

  if (oldChart) oldChart.destroy();

  return new Chart(canvas, {
    type: 'line',
    data: {
      labels,
      datasets: [{
        label,
        data: values,
        borderWidth: 2,
        tension: 0.2,
        fill: false
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        x: { title: { display: true, text: xTitle } },
        y: {
          beginAtZero: true,
          title: { display: true, text: yTitle }
        }
      }
    }
  });
}

// 3. DİRENÇ - AKIM
let resistanceChartInstance = null;
const resistanceChartButton = getElement('generateResistanceChart');

if (resistanceChartButton) {
  resistanceChartButton.addEventListener('click', function () {
    const voltage = getNumber('chartResistanceVoltage');
    const maxResistance = getNumber('chartResistanceMax');

    if (voltage === null || maxResistance === null ||
        voltage <= 0 || maxResistance <= 0) {
      alert('Geçerli değerler giriniz.');
      return;
    }

    const labels = [];
    const values = [];

    for (let i = 1; i <= 10; i++) {
      const r = maxResistance * i / 10;
      labels.push(Number(r.toFixed(2)));
      values.push(Number((voltage / r).toFixed(4)));
    }

    resistanceChartInstance = createElectricalChart(
      'resistanceChart', resistanceChartInstance,
      labels, values, 'Akım (A)', 'Direnç (Ω)', 'Akım (A)'
    );
  });
}

// 4. KAPASİTİF REAKTANS
let capacitiveChartInstance = null;
const capacitiveChartButton = getElement('generateCapacitiveChart');

if (capacitiveChartButton) {
  capacitiveChartButton.addEventListener('click', function () {
    const capacitance = getNumber('chartCapacitance');
    const maxFrequency = getNumber('chartFrequencyMaxC');

    if (capacitance === null || maxFrequency === null ||
        capacitance <= 0 || maxFrequency <= 0) {
      alert('Geçerli değerler giriniz.');
      return;
    }

    const c = capacitance / 1000000;
    const labels = [];
    const values = [];

    for (let i = 1; i <= 10; i++) {
      const f = maxFrequency * i / 10;
      labels.push(Number(f.toFixed(2)));
      values.push(Number((1 / (2 * Math.PI * f * c)).toFixed(2)));
    }

    capacitiveChartInstance = createElectricalChart(
      'capacitiveChart', capacitiveChartInstance,
      labels, values, 'Kapasitif Reaktans (Ω)',
      'Frekans (Hz)', 'Reaktans (Ω)'
    );
  });
}

// 5. ENDÜKTİF REAKTANS
let inductiveChartInstance = null;
const inductiveChartButton = getElement('generateInductiveChart');

if (inductiveChartButton) {
  inductiveChartButton.addEventListener('click', function () {
    const inductance = getNumber('chartInductance');
    const maxFrequency = getNumber('chartFrequencyMaxL');

    if (inductance === null || maxFrequency === null ||
        inductance <= 0 || maxFrequency <= 0) {
      alert('Geçerli değerler giriniz.');
      return;
    }

    const l = inductance / 1000;
    const labels = [];
    const values = [];

    for (let i = 0; i <= 10; i++) {
      const f = maxFrequency * i / 10;
      labels.push(Number(f.toFixed(2)));
      values.push(Number((2 * Math.PI * f * l).toFixed(2)));
    }

    inductiveChartInstance = createElectricalChart(
      'inductiveChart', inductiveChartInstance,
      labels, values, 'Endüktif Reaktans (Ω)',
      'Frekans (Hz)', 'Reaktans (Ω)'
    );
  });
}

// 6. ÜÇ FAZ AKTİF GÜÇ
let threePhaseChartInstance = null;
const threePhaseChartButton = getElement('generateThreePhaseChart');

if (threePhaseChartButton) {
  threePhaseChartButton.addEventListener('click', function () {
    const voltage = getNumber('chartThreePhaseVoltage');
    const current = getNumber('chartThreePhaseCurrent');

    if (voltage === null || current === null ||
        voltage <= 0 || current <= 0) {
      alert('Geçerli değerler giriniz.');
      return;
    }

    const labels = [];
    const values = [];

    for (let i = 1; i <= 10; i++) {
      const pf = i / 10;
      const power = Math.sqrt(3) * voltage * current * pf / 1000;

      labels.push(pf.toFixed(1));
      values.push(Number(power.toFixed(3)));
    }

    threePhaseChartInstance = createElectricalChart(
      'threePhaseChart', threePhaseChartInstance,
      labels, values, 'Aktif Güç (kW)',
      'Güç Faktörü (cosφ)', 'Aktif Güç (kW)'
    );
  });
}
console.log("Elektrik LAB: initializeApp çağrısı bekleniyor.");
document.addEventListener('DOMContentLoaded', initializeApp);